package rm.chatzo.app

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** last keyboard height in px, remembered so the attach sheet can open at the same size */
object Kb { var px = 0 }

const val I_SMILE = "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z M8 14s1.5 2 4 2 4-2 4-2 M9 9.5h.01 M15 9.5h.01"
const val I_MIC = "M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z M19 10v2a7 7 0 0 1-14 0v-2 M12 19v3 M8 22h8"
const val I_CONTRAST = "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z M12 3v18 M12 7a5 5 0 0 1 0 10z"
const val I_CLIP = "M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"
private const val A_GALLERY = "M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z M8.5 8a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3z M21 15l-5-5L5 21"
const val I_CAMERA = "M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z M12 9a4 4 0 1 0 0 8 4 4 0 0 0 0-8z"
private const val A_PIN = "M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z M12 7a3 3 0 1 0 0 6 3 3 0 0 0 0-6z"
private const val A_USER = "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2 M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z"
private const val A_DOC = "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z M14 2v6h6 M16 13H8 M16 17H8"
private const val A_POLL = "M18 20V10 M12 20V4 M6 20v-6"
private const val A_PAY = "M6 3h12 M6 8h12 M6 13h4a4 4 0 0 0 0-5 M10 13l7 8"
private const val A_EVENT = "M19 4H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z M16 2v4 M8 2v4 M3 10h18"
private const val A_AI = "M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"

private class Opt(val label: String, val path: String, val color: Color)

private val OPTS = listOf(
    Opt("Gallery", A_GALLERY, Color(0xFF4F8CFF)), Opt("Camera", I_CAMERA, Color(0xFFEF4565)),
    Opt("Location", A_PIN, Color(0xFF22C55E)), Opt("Contact", A_USER, Color(0xFF38A3F5)),
    Opt("Document", A_DOC, Color(0xFF7C6CF2)), Opt("Poll", A_POLL, Color(0xFFF5B83D)),
    Opt("Payment", A_PAY, Color(0xFF14B8A6)), Opt("Event", A_EVENT, Color(0xFFEF4565)),
    Opt("AI images", A_AI, Color(0xFF4F8CFF))
)

@Composable
private fun Thumb(uri: Uri) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            try {
                if (Build.VERSION.SDK_INT >= 29) ctx.contentResolver.loadThumbnail(uri, Size(260, 260), null).asImageBitmap() else null
            } catch (e: Throwable) { null }
        }
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF2A3942))) {
        bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

/** WhatsApp-style attach sheet: options + recent photos; drag up for the full gallery, tick many photos and send together */
@Composable
fun AttachSheet(
    onDismiss: () -> Unit,
    onCamera: () -> Unit,
    onPickSystem: () -> Unit,
    onSoon: (String) -> Unit,
    onSend: (List<Uri>, String) -> Unit
) {
    val ctx = LocalContext.current
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    val density = androidx.compose.ui.platform.LocalDensity.current
    val kbPx = if (Kb.px > 200) Kb.px.toFloat() else with(density) { 300.dp.toPx() }
    val fullPx = androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp.dp.let { with(density) { it.toPx() } } * 0.92f
    val maxExt = (fullPx - kbPx).coerceAtLeast(1f)
    var ext by remember { mutableFloatStateOf(0f) }
    var galleryTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(galleryTick) {
        if (galleryTick > 0) androidx.compose.animation.core.animate(ext, maxExt, animationSpec = androidx.compose.animation.core.tween(280)) { v, _ -> ext = v }
    }
    val expanded = ext > with(density) { 60.dp.toPx() }
    val gridState = androidx.compose.foundation.lazy.grid.rememberLazyGridState()
    val nested = remember(maxExt) {
        object : androidx.compose.ui.input.nestedscroll.NestedScrollConnection {
            override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
                val dy = available.y
                if (dy < 0f && ext < maxExt) {
                    val n = (ext - dy).coerceAtMost(maxExt); val used = ext - n; ext = n
                    return androidx.compose.ui.geometry.Offset(0f, used)
                }
                if (dy > 0f && ext > 0f && !gridState.canScrollBackward) {
                    val n = (ext - dy).coerceAtLeast(0f); val used = ext - n; ext = n
                    return androidx.compose.ui.geometry.Offset(0f, used)
                }
                return androidx.compose.ui.geometry.Offset.Zero
            }
        }
    }
    val sel = remember { mutableStateListOf<Uri>() }
    var caption by remember { mutableStateOf("") }
    val images by produceState<List<Uri>>(emptyList(), granted) {
        if (!granted) return@produceState
        value = withContext(Dispatchers.IO) {
            val out = ArrayList<Uri>()
            try {
                ctx.contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Images.Media._ID), null, null,
                    MediaStore.Images.Media.DATE_ADDED + " DESC"
                )?.use { c ->
                    val idc = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    while (c.moveToNext() && out.size < 200) out.add(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(idc)))
                }
            } catch (e: Throwable) {}
            out
        }
    }
    var drag by remember { mutableFloatStateOf(0f) }

    androidx.activity.compose.BackHandler { if (ext > 1f) ext = 0f else onDismiss() }
    run {
        run {
            val h = with(density) { (kbPx + ext).toDp() }
            Column(
                Modifier.fillMaxWidth().height(h)
                    .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                    .background(Color(0xFF12191E))
            ) {
                // handle + header (drag here)
                Column(
                    Modifier.fillMaxWidth().pointerInput(maxExt) {
                        detectVerticalDragGestures { _, d -> ext = (ext - d).coerceIn(0f, maxExt) }
                    }
                ) {
                    Box(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 6.dp), contentAlignment = Alignment.Center) {
                        Box(Modifier.width(36.dp).height(4.dp).clip(CircleShape).background(Color(0xFF5B6770)))
                    }
                    if (expanded) {
                        Row(Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(44.dp).clickable { ext = 0f }, contentAlignment = Alignment.Center) {
                                Text("✕", color = Color.White, fontSize = 20.sp)
                            }
                            Text("Recents", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                            Spacer(Modifier.width(44.dp))
                        }
                    } else {
                        for (row in OPTS.chunked(5)) {
                            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                                for (o in row) {
                                    Column(
                                        Modifier.weight(1f).clickable {
                                            when (o.label) {
                                                "Gallery" -> galleryTick++
                                                "Camera" -> { onDismiss(); onCamera() }
                                                else -> onSoon(o.label)
                                            }
                                        },
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) { LineIcon(o.path, o.color, 28) }
                                        Text(o.label, color = Color(0xFFB8C4CB), fontSize = 12.sp)
                                    }
                                }
                                repeat(5 - row.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                    }
                }
                if (!granted) {
                    Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text("Allow photo access to see your recent photos here", color = Color(0xFFB8C4CB), fontSize = 14.sp, textAlign = TextAlign.Center,
                            modifier = Modifier.padding(16.dp))
                        TextButton(onClick = { ask.launch(perm) }) { Text("Allow", color = TealLight, fontWeight = FontWeight.Bold) }
                    }
                } else {
                    LazyVerticalGrid(GridCells.Fixed(4), Modifier.weight(1f).fillMaxWidth().nestedScroll(nested), state = gridState, horizontalArrangement = Arrangement.spacedBy(1.dp), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        items(images, key = { it.toString() }) { u ->
                            val idx = sel.indexOf(u)
                            Box(Modifier.aspectRatio(1f).clickable {
                                if (idx >= 0) sel.remove(u) else if (sel.size < 10) sel.add(u)
                                else onSoon("max10")
                            }) {
                                Thumb(u)
                                if (idx >= 0) Box(Modifier.fillMaxSize().background(Color(0x66FFFFFF)))
                                if (idx >= 0) Box(
                                    Modifier.align(Alignment.TopEnd).padding(5.dp).size(24.dp).clip(CircleShape).background(Color(0xFF22C55E)),
                                    contentAlignment = Alignment.Center
                                ) { Text("${idx + 1}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                }
                if (sel.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth().background(Color(0xFF12191E)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextField(
                            caption, { caption = it }, placeholder = { Text("Add a caption…", color = Muted) }, maxLines = 3,
                            modifier = Modifier.weight(1f).clip(RoundedCornerShape(26.dp)),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF202C33), unfocusedContainerColor = Color(0xFF202C33),
                                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, cursorColor = TealLight
                            )
                        )
                        Spacer(Modifier.width(8.dp))
                        Box(Modifier.size(52.dp)) {
                            Box(
                                Modifier.fillMaxSize().clip(CircleShape).background(Teal).clickable {
                                    val l = sel.toList(); val c = caption.trim()
                                    onDismiss(); onSend(l, c)
                                }, contentAlignment = Alignment.Center
                            ) { Text("➤", color = Color.White, fontSize = 22.sp) }
                            Box(
                                Modifier.align(Alignment.TopEnd).size(20.dp).clip(CircleShape).background(Color.White),
                                contentAlignment = Alignment.Center
                            ) { Text("${sel.size}", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        }
    }
}
