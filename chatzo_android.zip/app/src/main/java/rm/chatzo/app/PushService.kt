package rm.chatzo.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import androidx.core.app.NotificationCompat
import androidx.core.app.Person
import androidx.core.graphics.drawable.IconCompat
import com.google.android.gms.tasks.Tasks
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import java.util.concurrent.TimeUnit

class PushService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        Repo.saveToken(token)
    }

    override fun onMessageReceived(m: RemoteMessage) {
        val d = m.data
        val from = d["sid"] ?: d["from"] ?: return
        val name = (d["name"] ?: "Chatzo").ifBlank { "Chatzo" }
        val text = d["text"] ?: ""
        try { kotlinx.coroutines.runBlocking { Repo.markDelivered(from) } } catch (e: Throwable) {}
        if (Repo.foreground) return // app is open, no need for a notification

        var icon: Bitmap? = null
        try {
            val doc = Tasks.await(FirebaseFirestore.getInstance().document("users/$from").get(), 6, TimeUnit.SECONDS)
            val photo = doc.getString("photo") ?: ""
            if (photo.isNotBlank()) icon = Repo.decodeDataUrl(photo)?.let { circle(it) }
        } catch (e: Exception) {}

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("messages", "Messages", NotificationManager.IMPORTANCE_HIGH))
        }
        val id = from.hashCode()
        val me = Person.Builder().setName("You").build()
        val pb = Person.Builder().setName(name).setKey(from)
        if (icon != null) pb.setIcon(IconCompat.createWithBitmap(icon))
        val person = pb.build()

        var style: NotificationCompat.MessagingStyle? = null
        try {
            nm.activeNotifications.firstOrNull { it.id == id }?.let {
                style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(it.notification)
            }
        } catch (e: Exception) {}
        val st = style ?: NotificationCompat.MessagingStyle(me)
        st.addMessage(text, System.currentTimeMillis(), person)

        val intent = Intent(this, MainActivity::class.java)
            .putExtra("from", from).putExtra("name", name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(this, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val n = NotificationCompat.Builder(this, "messages")
            .setSmallIcon(R.drawable.ic_stat)
            .setColor(0xFF0F766E.toInt())
            .setStyle(st)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setOnlyAlertOnce(false)
        if (icon != null) n.setLargeIcon(icon)
        try { nm.notify(id, n.build()) } catch (e: SecurityException) {}
    }

    private fun circle(src: Bitmap): Bitmap {
        val s = minOf(src.width, src.height)
        val out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        c.drawCircle(s / 2f, s / 2f, s / 2f, p)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        c.drawBitmap(src, -(src.width - s) / 2f, -(src.height - s) / 2f, p)
        return out
    }
}
