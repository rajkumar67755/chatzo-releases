package rm.chatzo.app

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions

class ChatzoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (FirebaseApp.getApps(this).isEmpty()) {
            val o = FirebaseOptions.Builder()
                .setApiKey("AIzaSyDU8xJtT86wQWYOqkdKNJ6oyrUZ79cCAZY")
                .setApplicationId("1:416178695416:android:4234ab8ec1c9e4104c1f0d")
                .setProjectId("chatzo-fb739")
                .setStorageBucket("chatzo-fb739.firebasestorage.app")
                .setGcmSenderId("416178695416")
                .build()
            FirebaseApp.initializeApp(this, o)
        }
    }
}
