package rm.chatzo.app

import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val Bg = Color(0xFF0B141A)
val Panel = Color(0xFF111B21)
val Bar = Color(0xFF1F2C34)
val Teal = Color(0xFF0F766E)
val TealLight = Color(0xFF2DD4BF)
val OutBubble = Color(0xFF0B5F58)
val InBubble = Color(0xFF202C33)
val Muted = Color(0xFF8696A0)
val TickBlue = Color(0xFF53BDEB)

@Composable
fun ChatzoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Teal, onPrimary = Color.White, background = Bg, surface = Panel,
            onSurface = Color.White, onBackground = Color.White, secondary = TealLight
        ), content = content
    )
}

// ---------- images ----------
private val bmpCache = object : LruCache<Int, ImageBitmap>(24) {}

@Composable
fun rememberBitmap(src: String): ImageBitmap? {
    val key = src.hashCode() * 31 + src.length
    val st = produceState<ImageBitmap?>(bmpCache.get(key), key) {
        if (src.isBlank()) { value = null; return@produceState }
        val c = bmpCache.get(key)
        if (c != null) { value = c; return@produceState }
        val b = withContext(Dispatchers.Default) { Repo.decodeDataUrl(src)?.asImageBitmap() }
        if (b != null) bmpCache.put(key, b)
        value = b
    }
    return st.value
}

@Composable
fun Avatar(name: String, photo: String, size: Int = 48, modifier: Modifier = Modifier, person: Boolean = false) {
    val bmp = rememberBitmap(photo)
    Box(
        modifier.size(size.dp).clip(CircleShape).background(Teal),
        contentAlignment = Alignment.Center
    ) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else if (person) androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
            val w = this.size.width
            drawCircle(Color.White.copy(alpha = 0.9f), w * 0.19f, androidx.compose.ui.geometry.Offset(w * 0.5f, w * 0.38f))
            drawCircle(Color.White.copy(alpha = 0.9f), w * 0.36f, androidx.compose.ui.geometry.Offset(w * 0.5f, w * 1.0f))
        }
        else Text(
            (name.trim().firstOrNull() ?: '?').uppercase(),
            color = Color.White, fontSize = (size * 0.42f).sp, fontWeight = FontWeight.SemiBold
        )
    }
}

fun lastSeen(t: Long): String {
    val f = SimpleDateFormat("yyyyMMdd", Locale.getDefault())
    return if (f.format(Date(t)) == f.format(Date())) "today at " + hm(t)
    else SimpleDateFormat("d/M", Locale.getDefault()).format(Date(t)) + " " + hm(t)
}
fun hm(t: Long): String = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(t))
fun stamp(t: Long): String {
    if (t == 0L) return ""
    val d = Date(t)
    val f = SimpleDateFormat("yyyyMMdd", Locale.getDefault())
    return if (f.format(d) == f.format(Date())) hm(t) else SimpleDateFormat("d/M/yy", Locale.getDefault()).format(d)
}

@Composable
fun Ticks(st: String) {
    Text(
        if (st == "sent") "✓" else "✓✓",
        color = if (st == "read") TickBlue else Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold
    )
}

// ---------- splash / login / setup ----------
@Composable
fun Splash() {
    Box(Modifier.fillMaxSize().background(Teal), contentAlignment = Alignment.Center) {
        Text("Chatzo", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun LoginScreen(busy: Boolean, error: String, onGoogle: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Bg).systemBarsPadding().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(88.dp).clip(CircleShape).background(Teal), contentAlignment = Alignment.Center) {
            Text("C", color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(20.dp))
        Text("Chatzo", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Simple, fast messaging", color = Muted, fontSize = 15.sp)
        Spacer(Modifier.height(48.dp))
        Button(
            onClick = onGoogle, enabled = !busy, modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(26.dp)
        ) { Text(if (busy) "Please wait…" else "Continue with Google", fontSize = 16.sp) }
        if (error.isNotBlank()) {
            Spacer(Modifier.height(16.dp))
            Text(error, color = Color(0xFFFF8A80), fontSize = 13.sp)
        }
    }
}

@Composable
fun SetupScreen(initialName: String, error: String, busy: Boolean, onSave: (String, String) -> Unit, onLogout: () -> Unit) {
    var name by remember { mutableStateOf(initialName) }
    var phone by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().background(Bg).systemBarsPadding().imePadding().padding(28.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Set up your profile", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Friends will find you by your phone number.", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(name, { name = it }, label = { Text("Your name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            phone, { phone = it.filter { c -> c.isDigit() || c == '+' || c == ' ' } },
            label = { Text("Phone number") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        if (error.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(error, color = Color(0xFFFF8A80), fontSize = 13.sp)
        }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { onSave(name.trim(), Repo.normPhone(phone)) },
            enabled = !busy && name.isNotBlank() && Repo.normPhone(phone).length >= 10,
            modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(25.dp)
        ) { Text(if (busy) "Saving…" else "Continue") }
        TextButton(onClick = onLogout, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Use another account", color = Muted) }
    }
}

