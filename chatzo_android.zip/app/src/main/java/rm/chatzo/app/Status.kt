package rm.chatzo.app

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.draw.scale as drawScale
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val STATUS_COLORS = listOf(0xFF0F766E, 0xFF7C3AED, 0xFFB91C1C, 0xFF1D4ED8, 0xFFB45309, 0xFF047857).map { Color(it) }

private const val I_PLUS = "M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z M12 8v8 M8 12h8"
private const val I_SEARCH = "M11 3a8 8 0 1 0 0 16 8 8 0 0 0 0-16z M21 21l-4.3-4.3"
private const val I_CHAT = "M21 11.5a8.4 8.4 0 0 1-9 8.4 8.5 8.5 0 0 1-3.8-.9L3 21l1.9-5.2A8.4 8.4 0 0 1 3.9 11.5 8.5 8.5 0 0 1 12.4 3 8.4 8.4 0 0 1 21 11.5z"
private const val I_HOME = "M3 10.5L12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"
private const val I_REELS = "M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z M10 8.5v7l6-3.5z"
private const val I_FRIENDS = "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2 M9 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z M23 21v-2a4 4 0 0 0-3-3.9 M16 3.1a4 4 0 0 1 0 7.8"
private const val I_BELL = "M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9 M13.7 21a2 2 0 0 1-3.4 0"
private const val I_USER = "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2 M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z"
private const val I_IMAGE = "M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z M8.5 8a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3z M21 15l-5-5L5 21"

@Composable
fun LineIcon(d: String, color: Color, size: Int = 24) {
    val path = remember(d) { PathParser().parsePathString(d).toPath() }
    Canvas(Modifier.size(size.dp)) {
        val k = this.size.width / 24f
        withTransform({ scale(k, k, Offset.Zero) }) {
            drawPath(path, color, style = Stroke(width = 1.9f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

/** icon button with a touch effect: it shrinks a little and gets a soft round highlight while pressed */
@Composable
private fun TouchIcon(d: String, color: Color, box: Int = 44, icon: Int = 24, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.8f else 1f, label = "tap")
    Box(
        Modifier.size(box.dp).drawScale(sc).clip(CircleShape)
            .background(if (pressed) Color(0x33FFFFFF) else Color.Transparent)
            .clickable(interactionSource = src, indication = null) { onClick() },
        contentAlignment = Alignment.Center
    ) { LineIcon(d, color, icon) }
}

@Composable
fun StatusScreen(
    myId: String, isAdmin: Boolean, onOpen: (String, String) -> Unit,
    onAdmin: () -> Unit, onLogout: () -> Unit, onGoChats: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var friends by remember { mutableStateOf<List<Friend>>(emptyList()) }
    var statuses by remember { mutableStateOf<Map<String, StatusItem>>(emptyMap()) }
    var menu by remember { mutableStateOf("") }
    var diag by remember { mutableStateOf<String?>(null) }
    var choose by remember { mutableStateOf(false) }
    var writing by remember { mutableStateOf(false) }
    var open by remember { mutableStateOf<StatusItem?>(null) }
    var posting by remember { mutableStateOf(false) }
    var sub by remember { mutableIntStateOf(0) }
    var searching by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }

    DisposableEffect(Unit) {
        val r = Repo.listenFriends { friends = it }
        onDispose { r?.remove() }
    }
    val key = friends.map { it.id }.sorted().joinToString(",")
    DisposableEffect(key, myId) {
        val stop = Repo.listenStatuses(listOf(myId) + friends.map { it.id }) { statuses = it }
        onDispose { stop() }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            posting = true
            val d = withContext(Dispatchers.IO) { Repo.readPhoto(ctx, uri, 1080, 700000) }
            val err: String? = if (d == null) "Couldn't use that photo" else Repo.postStatus(d, "", 0)
            posting = false
            Toast.makeText(ctx, err ?: "Status posted", Toast.LENGTH_SHORT).show()
        }
    }
    val mine = statuses[myId]
    fun nameOf(s: StatusItem): String =
        if (s.uid == myId) "My status"
        else s.name.ifBlank { friends.firstOrNull { it.id == s.uid }?.name?.ifBlank { null } ?: Repo.profile(s.uid)?.name ?: "" }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            GearIcon(Modifier.clickable { })
            Spacer(Modifier.width(12.dp))
            Text("Status", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TouchIcon(I_PLUS, Color.White) { choose = true }
            TouchIcon(I_SEARCH, Color.White) { searching = !searching; if (!searching) q = "" }
            TouchIcon(I_CHAT, Color.White) { onGoChats() }
        }
        if (searching) {
            OutlinedTextField(
                q, { q = it }, singleLine = true, placeholder = { Text("Search", color = Muted) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
            )
        }
        // icon tab row
        Row(Modifier.fillMaxWidth().height(48.dp)) {
            listOf(I_HOME, I_REELS, I_FRIENDS, I_BELL, I_USER).forEachIndexed { i, ic ->
                val src = remember { MutableInteractionSource() }
                val pressed by src.collectIsPressedAsState()
                val sc by animateFloatAsState(if (pressed) 0.8f else if (sub == i) 1.1f else 1f, label = "tab")
                Box(
                    Modifier.weight(1f).fillMaxHeight()
                        .background(if (pressed) Color(0x22FFFFFF) else Color.Transparent)
                        .clickable(interactionSource = src, indication = null) { sub = i },
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.drawScale(sc)) { LineIcon(ic, if (sub == i) TealLight else Muted, 26) }
                    if (sub == i) Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp).background(TealLight))
                }
            }
        }
        HorizontalDivider(color = Color(0x22FFFFFF))

        when (sub) {
            0 -> {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.weight(1f).height(42.dp).clip(RoundedCornerShape(21.dp)).border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(21.dp))
                            .clickable { writing = true }.padding(horizontal = 16.dp),
                        contentAlignment = Alignment.CenterStart
                    ) { Text("What's on your mind?", color = Muted, fontSize = 15.sp) }
                    Spacer(Modifier.width(6.dp))
                    TouchIcon(I_IMAGE, Color(0xFF45BD62), 48, 28) {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                }
                HorizontalDivider(color = Color(0x22FFFFFF), thickness = 6.dp)
                val list = statuses.values.filter { it.live && (q.isBlank() || nameOf(it).contains(q, true)) }
                    .sortedWith(compareByDescending<StatusItem> { it.uid == myId }.thenByDescending { it.at })
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item { CreateCard(mine?.photo ?: "") { choose = true } }
                    items(list, key = { it.uid }) { s -> StatusCard(s, nameOf(s)) { open = s } }
                }
                if (posting) Text("Posting…", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
            }
            2 -> {
                val shown = friends.filter { q.isBlank() || it.name.contains(q, true) || (statuses[it.id]?.name ?: "").contains(q, true) }
                if (shown.isEmpty()) Text("No friends yet", color = Muted, modifier = Modifier.padding(20.dp))
                LazyColumn(Modifier.fillMaxSize()) {
                    items(shown, key = { it.id }) { f ->
                        val st = statuses[f.id]
                        val nm = st?.name?.ifBlank { null } ?: f.name
                        Row(
                            Modifier.fillMaxWidth().clickable { onOpen(f.id, f.name) }.padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Avatar(nm, st?.photo ?: "", 52, person = true)
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text(nm, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                                if (!st?.bio.isNullOrBlank()) Text(st!!.bio, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
            4 -> StatusProfile(mine)
            else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Coming soon", color = Muted, fontSize = 16.sp)
            }
        }
    }

    diag?.let { t ->
        AlertDialog(
            onDismissRequest = { diag = null },
            title = { Text("Notification check") },
            text = { Text(t) },
            confirmButton = { TextButton(onClick = { diag = null }) { Text("Close") } }
        )
    }
    if (choose) {
        AlertDialog(
            onDismissRequest = { choose = false },
            title = { Text("Create status") },
            text = { Text("Share a photo or a text status. It stays for 24 hours.") },
            confirmButton = {
                TextButton(onClick = {
                    choose = false
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }) { Text("Photo") }
            },
            dismissButton = { TextButton(onClick = { choose = false; writing = true }) { Text("Text") } }
        )
    }
    if (writing) {
        var txt by remember { mutableStateOf("") }
        var col by remember { mutableStateOf(0) }
        Dialog(onDismissRequest = { writing = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Column(Modifier.fillMaxSize().background(STATUS_COLORS[col]).systemBarsPadding().padding(12.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { writing = false }) { Text("Close", color = Color.White) }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = {
                        if (txt.isNotBlank()) scope.launch {
                            posting = true
                            val err = Repo.postStatus("", txt.trim(), col)
                            posting = false
                            if (err == null) writing = false
                            Toast.makeText(ctx, err ?: "Status posted", Toast.LENGTH_SHORT).show()
                        }
                    }) { Text("Post", color = Color.White, fontWeight = FontWeight.Bold) }
                }
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    TextField(
                        txt, { if (it.length <= 300) txt = it },
                        placeholder = { Text("Type a status", color = Color(0xB3FFFFFF), fontSize = 26.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) },
                        textStyle = TextStyle(color = Color.White, fontSize = 26.sp, textAlign = TextAlign.Center),
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                            cursorColor = Color.White
                        )
                    )
                }
                Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    STATUS_COLORS.forEachIndexed { i, c ->
                        Box(
                            Modifier.size(34.dp).clip(CircleShape).background(c)
                                .border(if (i == col) 3.dp else 1.dp, Color.White, CircleShape)
                                .clickable { col = i }
                        )
                    }
                }
            }
        }
    }
    open?.let { s ->
        StatusViewer(s, nameOf(s), s.uid == myId, { open = null }) {
            open = null
            scope.launch { Repo.deleteStatus()?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() } }
        }
    }
}

@Composable
private fun StatusProfile(mine: StatusItem?) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var nm by remember(mine?.name) { mutableStateOf(mine?.name ?: "") }
    var bio by remember(mine?.bio) { mutableStateOf(mine?.bio ?: "") }
    var newPhoto by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val d = withContext(Dispatchers.IO) { Repo.readPhoto(ctx, uri, 320, 90000) }
            if (d != null) newPhoto = d else Toast.makeText(ctx, "Couldn't use that photo", Toast.LENGTH_SHORT).show()
        }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp)) {
        item {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Avatar(nm.ifBlank { "Me" }, newPhoto ?: mine?.photo ?: "", 110, Modifier.clickable {
                    pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }, person = true)
                TextButton(onClick = { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                    Text("Change photo", color = TealLight)
                }
                Text("This profile is only for Status. Your chat photo is not shown here.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(nm, { if (it.length <= 40) nm = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(bio, { if (it.length <= 150) bio = it }, label = { Text("Bio") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(16.dp))
                TextButton(
                    enabled = !busy,
                    onClick = {
                        scope.launch {
                            busy = true
                            val err = Repo.saveStatusProfile(nm, bio, newPhoto)
                            busy = false
                            Toast.makeText(ctx, err ?: "Saved", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) { Text(if (busy) "Saving…" else "Save", color = TealLight, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
            }
        }
    }
}

@Composable
private fun CreateCard(photo: String, onClick: () -> Unit) {
    val bmp = rememberBitmap(photo)
    Box(Modifier.width(142.dp).height(236.dp).clip(RoundedCornerShape(14.dp)).background(Panel).clickable { onClick() }) {
        Box(Modifier.fillMaxWidth().height(180.dp).background(Color(0xFF2A3942)).clipToBounds()) {
            if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Canvas(Modifier.fillMaxSize()) {
                val w = size.width; val h = size.height
                drawCircle(Color(0xFF55636B), w * 0.2f, Offset(w / 2f, h * 0.38f))
                drawCircle(Color(0xFF55636B), w * 0.38f, Offset(w / 2f, h * 0.98f))
            }
        }
        Box(
            Modifier.align(Alignment.TopCenter).offset(y = 158.dp).size(44.dp).clip(CircleShape)
                .background(Teal).border(3.dp, Panel, CircleShape),
            contentAlignment = Alignment.Center
        ) { Text("+", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        Text(
            "Create status", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center,
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 12.dp)
        )
    }
}

@Composable
private fun StatusCard(s: StatusItem, name: String, onClick: () -> Unit) {
    val bmp = rememberBitmap(s.img)
    Box(
        Modifier.width(142.dp).height(236.dp).clip(RoundedCornerShape(14.dp))
            .background(STATUS_COLORS[s.color.coerceIn(0, STATUS_COLORS.lastIndex)]).clickable { onClick() }
    ) {
        if (s.img.isNotBlank() && bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else if (s.text.isNotBlank()) Text(
            s.text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
            maxLines = 8, overflow = TextOverflow.Ellipsis, modifier = Modifier.align(Alignment.Center).padding(12.dp)
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(0f to Color(0x66000000), 0.35f to Color.Transparent, 0.7f to Color.Transparent, 1f to Color(0xAA000000))
            )
        )
        Box(Modifier.padding(8.dp).size(44.dp).border(3.dp, TealLight, CircleShape).padding(3.dp)) { Avatar(name, s.photo, 38, person = true) }
        Text(
            name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.BottomStart).padding(8.dp)
        )
    }
}

@Composable
private fun StatusViewer(s: StatusItem, name: String, mine: Boolean, onClose: () -> Unit, onDelete: () -> Unit) {
    val bmp = rememberBitmap(s.img)
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize()
                .background(if (s.img.isNotBlank()) Color.Black else STATUS_COLORS[s.color.coerceIn(0, STATUS_COLORS.lastIndex)])
                .clickable { onClose() }
        ) {
            if (s.img.isNotBlank() && bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            else if (s.text.isNotBlank()) Text(
                s.text, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.Center).padding(24.dp)
            )
            Column(Modifier.align(Alignment.TopStart).systemBarsPadding().padding(16.dp)) {
                Text(name, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                Text(lastSeen(s.at), color = Color(0xCCFFFFFF), fontSize = 12.sp)
            }
            if (mine) TextButton(
                onClick = onDelete,
                modifier = Modifier.align(Alignment.BottomCenter).systemBarsPadding().padding(16.dp)
            ) { Text("Delete status", color = Color.White, fontWeight = FontWeight.Bold) }
        }
    }
}
