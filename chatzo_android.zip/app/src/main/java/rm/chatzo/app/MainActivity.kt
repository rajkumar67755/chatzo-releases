package rm.chatzo.app

import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.lifecycle.lifecycleScope
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainActivity : ComponentActivity() {
    private var presJob: Job? = null
    private var openFrom by mutableStateOf<Pair<String, String>?>(null)

    private fun readIntent(i: android.content.Intent?) {
        val f = i?.getStringExtra("from") ?: return
        openFrom = f to (i.getStringExtra("name") ?: "Chat")
        i.removeExtra("from")
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        readIntent(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        readIntent(intent)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) {}
                .launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { ChatzoTheme { Root() } }
    }

    override fun onStart() {
        super.onStart()
        Repo.foreground = true
        presJob = lifecycleScope.launch { while (true) { Repo.setPresence(true); delay(25000) } }
    }

    override fun onStop() {
        super.onStop()
        Repo.foreground = false
        presJob?.cancel()
        Repo.setPresence(false)
    }

    /** returns null on success, otherwise an error message ("" = cancelled quietly) */
    private suspend fun googleLogin(auto: Boolean): String? {
        return try {
            val cm = CredentialManager.create(this)
            val id = getString(R.string.web_client_id)
            val req = if (auto) GetCredentialRequest.Builder().addCredentialOption(
                GetGoogleIdOption.Builder().setFilterByAuthorizedAccounts(true).setAutoSelectEnabled(true)
                    .setServerClientId(id).build()
            ).build()
            else GetCredentialRequest.Builder().addCredentialOption(
                GetSignInWithGoogleOption.Builder(id).build()
            ).build()
            val c = cm.getCredential(this, req).credential
            if (c is CustomCredential && c.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val tok = GoogleIdTokenCredential.createFrom(c.data).idToken
                FirebaseAuth.getInstance().signInWithCredential(GoogleAuthProvider.getCredential(tok, null)).await()
                null
            } else "Unsupported login"
        } catch (e: androidx.credentials.exceptions.NoCredentialException) {
            if (auto) "" else "No Google account found on this phone."
        } catch (e: androidx.credentials.exceptions.GetCredentialCancellationException) {
            ""
        } catch (e: Exception) {
            if (auto) "" else (e.message ?: "Login failed")
        }
    }

    @Composable
    private fun Root() {
        val prefs = remember { getSharedPreferences("chatzo", MODE_PRIVATE) }
        val scope = rememberCoroutineScope()
        val actx = androidx.compose.ui.platform.LocalContext.current
        var upd by remember { mutableStateOf<Triple<String, String, String>?>(null) }
        var checked by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) { upd = Repo.checkUpdate(actx); checked = true }
        if (!checked) { Splash(); return }
        upd?.let { UpdateScreen(it.first, it.second, it.third); return }
        var user by remember { mutableStateOf(Repo.auth.currentUser) }
        DisposableEffect(Unit) {
            val l = FirebaseAuth.AuthStateListener { user = it.currentUser }
            Repo.auth.addAuthStateListener(l)
            onDispose { Repo.auth.removeAuthStateListener(l) }
        }
        var autoTrying by remember { mutableStateOf(user == null && !prefs.getBoolean("out", false)) }
        var busy by remember { mutableStateOf(false) }
        var loginErr by remember { mutableStateOf("") }

        LaunchedEffect(Unit) {
            if (autoTrying) {
                googleLogin(true)
                autoTrying = false
            }
        }

        val u = user
        if (u == null) {
            if (autoTrying) Splash()
            else LoginScreen(busy, loginErr) {
                busy = true; loginErr = ""
                scope.launch {
                    val r = googleLogin(false)
                    busy = false
                    if (r == null) prefs.edit().putBoolean("out", false).apply()
                    else loginErr = r
                }
            }
            return
        }

        // 0 = loading, 1 = has profile, 2 = needs setup, 3 = load failed
        var state by remember(u.uid) { mutableIntStateOf(0) }
        var retry by remember { mutableIntStateOf(0) }
        var isAdmin by remember(u.uid) { mutableStateOf(false) }
        LaunchedEffect(u.uid, retry) {
            state = 0
            state = try { if (Repo.loadMyProfile(u.uid) != null) 1 else 2 } catch (e: Exception) { 3 }
            if (state == 1) {
                isAdmin = Repo.isAdmin()
                if (!isAdmin && Repo.isBlockedByAdmin()) {
                    loginErr = "This account has been blocked by the admin."
                    Repo.auth.signOut()
                }
            }
        }
        LaunchedEffect(state) {
            if (state == 1) {
                try {
                    com.google.firebase.messaging.FirebaseMessaging.getInstance().token
                        .addOnSuccessListener { t -> Repo.saveToken(t) }
                } catch (e: Exception) {}
            }
        }
        val logout: () -> Unit = {
            prefs.edit().putBoolean("out", true).apply()
            scope.launch {
                Repo.setPresence(false)
                Repo.clearToken()
                Repo.auth.signOut()
            }
        }
        when (state) {
            0 -> Splash()
            3 -> LoginScreen(false, "Couldn't connect. Check your internet and try again.") { retry++ }
            2 -> {
                var err by remember { mutableStateOf("") }
                var saving by remember { mutableStateOf(false) }
                SetupScreen(u.displayName ?: "", err, saving, { n, p ->
                    saving = true; err = ""
                    scope.launch {
                        val r = Repo.createProfile(u, n, p)
                        saving = false
                        if (r == null) state = 1 else err = r
                    }
                }, logout)
            }
            else -> {
                var chat by remember { mutableStateOf<Pair<String, String>?>(null) }
                var page by remember { mutableStateOf("main") }
                BackHandler(enabled = chat != null || page != "main") {
                    if (chat != null) chat = null else page = "main"
                }
                LaunchedEffect(openFrom) { openFrom?.let { chat = it; page = "main"; openFrom = null } }
                val c = chat
                when {
                    c != null -> ChatScreen(u.uid, c.first, c.second) { chat = null }
                    page == "profile" -> ProfileScreen(u.uid) { page = "main" }
                    page == "admin" -> AdminScreen(u.uid) { page = "main" }
                    else -> MainScreen(u.uid, isAdmin, { id, n -> chat = id to n }, { page = "profile" }, { page = "admin" }, logout)
                }
            }
        }
    }
}
