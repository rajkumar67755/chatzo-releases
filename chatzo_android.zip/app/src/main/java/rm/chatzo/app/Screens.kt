package rm.chatzo.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

val Red = Color(0xFFFF8A80)

// ---------- helpers ----------
fun cropSquare(src: Bitmap, z: Float, x: Float, y: Float, size: Int): Bitmap {
    val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(out)
    c.drawColor(0xFF0F766E.toInt())
    val k = maxOf(size.toFloat() / src.width, size.toFloat() / src.height) * z
    val w = src.width * k
    val h = src.height * k
    val m = Matrix()
    m.postScale(k, k)
    m.postTranslate((size - w) * x, (size - h) * y)
    c.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
    return out
}

fun saveToGallery(ctx: Context, bmp: Bitmap): Boolean = try {
    val name = "chatzo-" + System.currentTimeMillis() + ".jpg"
    if (Build.VERSION.SDK_INT >= 29) {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Chatzo")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)!!
        ctx.contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
    } else {
        val dir = ctx.getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES)!!
        File(dir, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
    }
    true
} catch (e: Throwable) { false }

val EMOJIS = ("😀😃😄😁😆😅😂🤣😊😇🙂😉😍🥰😘😗😋😛😜🤪😎🤩🥳😏😒😞😔😟😕🙁😣😖😫😩🥺😢😭😤😠😡🤬🤯😳🥵🥶😱😨😰😥😓🤗🤔🤭🤫😶😐😑😬🙄😯😴🤤😪🤐🥴🤢🤮🤧😷" +
    "👍👎👌✌🤞🤟🤘👏🙌🙏💪👋🤝❤🧡💛💚💙💜🖤💔💕💖💗💯🔥✨🎉🎂🎁🌹☀🌙⭐🍕🍔🍟☕⚽🏏🎮🎵📷📞💬✅❌").let { str ->
    val out = ArrayList<String>()
    var i = 0
    while (i < str.length) {
        val cp = str.codePointAt(i)
        val n = Character.charCount(cp)
        out.add(str.substring(i, i + n))
        i += n
    }
    out.filter { it.isNotBlank() }
}

// ---------- reusable pieces ----------
@Composable
fun DefaultBg() {
    Image(androidx.compose.ui.res.painterResource(R.drawable.chat_bg), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
}

@Composable
fun WallBg(w: Wall?, fallback: Boolean = false) {
    if (w == null || w.none || w.src.isBlank()) { if (fallback) DefaultBg(); return }
    val b = rememberBitmap(w.src)
    Box(Modifier.fillMaxSize()) {
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = (w.dim.coerceIn(0, 90)) / 100f)))
    }
}

class WallFlow {
    var key by mutableStateOf("")
    var src by mutableStateOf<String?>(null)
    var dim by mutableIntStateOf(25)
    var launch: (() -> Unit)? = null
    fun start(k: String) { key = k; launch?.invoke() }
}

@Composable
fun WallpaperHost(flow: WallFlow) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val d = withContext(Dispatchers.IO) { Repo.readPhoto(ctx, uri, 1280, 700000) }
            if (d != null) flow.src = d else Toast.makeText(ctx, "Couldn't use that photo", Toast.LENGTH_SHORT).show()
        }
    }
    SideEffect { flow.launch = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) } }
    val s = flow.src
    if (s != null) {
        Dialog(onDismissRequest = { flow.src = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding().padding(16.dp)) {
                Text("Background", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(16.dp))) {
                    WallBg(Wall(s, flow.dim, false))
                }
                Spacer(Modifier.height(12.dp))
                Text("Dim: " + flow.dim + "%", color = Muted)
                Slider(flow.dim.toFloat(), { flow.dim = it.toInt() }, valueRange = 0f..80f)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = { flow.src = null }, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(onClick = {
                        val k = flow.key; val d = flow.dim
                        flow.src = null
                        scope.launch {
                            val r = Repo.saveWall(k, s, d)
                            Toast.makeText(ctx, r ?: "Background saved", Toast.LENGTH_SHORT).show()
                        }
                    }, modifier = Modifier.weight(1f)) { Text("Save") }
                }
            }
        }
    }
}

@Composable
fun PhotoViewer(bmp: Bitmap, onClose: () -> Unit) {
    val ctx = LocalContext.current
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        var s by remember { mutableStateOf(1f) }
        var ox by remember { mutableStateOf(0f) }
        var oy by remember { mutableStateOf(0f) }
        val ib = remember(bmp) { bmp.asImageBitmap() }
        Box(
            Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    s = (s * zoom).coerceIn(1f, 6f)
                    if (s > 1f) { ox += pan.x; oy += pan.y } else { ox = 0f; oy = 0f }
                }
            }, contentAlignment = Alignment.Center
        ) {
            Image(ib, null, Modifier.fillMaxWidth().graphicsLayer(scaleX = s, scaleY = s, translationX = ox, translationY = oy), contentScale = ContentScale.Fit)
            Row(Modifier.align(Alignment.TopStart).fillMaxWidth().statusBarsPadding(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = {
                    val ok = saveToGallery(ctx, bmp)
                    Toast.makeText(ctx, if (ok) "Saved to Pictures/Chatzo" else "Couldn't save", Toast.LENGTH_SHORT).show()
                }) { Text("Download", color = Color.White) }
            }
        }
    }
}

@Composable
fun PeekDialog(name: String, photo: String, onClose: () -> Unit) {
    var big by remember { mutableStateOf<Bitmap?>(null) }
    val b = rememberBitmap(photo)
    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier.clip(RoundedCornerShape(20.dp)).background(Panel).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.size(240.dp).clip(RoundedCornerShape(16.dp)).background(Teal).clickable {
                    if (photo.isNotBlank()) big = Repo.decodeDataUrl(photo)
                }, contentAlignment = Alignment.Center
            ) {
                if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Text((name.trim().firstOrNull() ?: '?').uppercase(), color = Color.White, fontSize = 90.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            Text(name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            if (photo.isNotBlank()) Text("Tap the photo to open it", color = Muted, fontSize = 12.sp)
        }
    }
    big?.let { PhotoViewer(it) { big = null } }
}

// ---------- main (home + bottom navigation) ----------
@Composable
fun MainScreen(
    myId: String, isAdmin: Boolean,
    onOpen: (String, String) -> Unit, onProfile: () -> Unit, onAdmin: () -> Unit, onLogout: () -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    Box(Modifier.fillMaxSize().background(Bg)) {
        when (tab) {
            0 -> HomeScreen(myId, isAdmin, onOpen, onProfile, onAdmin, onLogout)
            1 -> StatusScreen(myId, isAdmin, onOpen, onAdmin, onLogout, onGoChats = { tab = 0 })
            3 -> BooksScreen()
            else -> {
                val t = listOf("", "Status", "Games", "Books", "Communities", "Calls")[tab]
                Column(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp)) {
                    Text(t, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(40.dp))
                    Text("$t is coming soon.", color = Muted, modifier = Modifier.align(Alignment.CenterHorizontally))
                }
            }
        }
        NavBar(
            tab, { tab = it },
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(start = 14.dp, end = 14.dp, bottom = 10.dp)
        )
    }
}

// ---------- bottom bar with the red light ----------
private val NavRed = Color(0xFFFF2A45)
private val NavGrey = Color(0xFFA9ABB0)
private val P_CHAT1 by lazy { androidx.core.graphics.PathParser.createPathFromPathData("M4 5.5A1.5 1.5 0 0 1 5.5 4h13A1.5 1.5 0 0 1 20 5.5v9a1.5 1.5 0 0 1-1.5 1.5H10l-4.5 4v-4h0A1.5 1.5 0 0 1 4 14.5z") }
private val P_CHAT2 by lazy { androidx.core.graphics.PathParser.createPathFromPathData("M8 8.5h8M8 12h5") }
private val P_COM1 by lazy { androidx.core.graphics.PathParser.createPathFromPathData("M7.5 18c0-2.5 2-4.2 4.5-4.2s4.5 1.7 4.5 4.2") }
private val P_COM2 by lazy { androidx.core.graphics.PathParser.createPathFromPathData("M2.5 17.5c.2-1.6 1.4-2.8 3-2.8") }
private val P_COM3 by lazy { androidx.core.graphics.PathParser.createPathFromPathData("M21.5 17.5c-.2-1.6-1.4-2.8-3-2.8") }
private val P_CALL by lazy { androidx.core.graphics.PathParser.createPathFromPathData("M5 4h3.5l1.8 4.5-2.2 1.4a11 11 0 0 0 5.5 5.5l1.4-2.2L20 15v3.5a1.5 1.5 0 0 1-1.6 1.5C10.5 19.5 4.5 13.5 4 5.6A1.5 1.5 0 0 1 5 4z") }

private val P_GAME by lazy { androidx.core.graphics.PathParser.createPathFromPathData("M6 9h12a4 4 0 0 1 4 4v2a3 3 0 0 1-5.2 2L15 15H9l-1.8 2A3 3 0 0 1 2 15v-2a4 4 0 0 1 4-4z") }
private val P_GAME2 by lazy { androidx.core.graphics.PathParser.createPathFromPathData("M7.5 11.5v3M6 13h3") }
private val P_BOOK1 by lazy { androidx.core.graphics.PathParser.createPathFromPathData("M4 5.5A1.5 1.5 0 0 1 5.5 4H19v13H5.5A1.5 1.5 0 0 0 4 18.5z") }
private val P_BOOK2 by lazy { androidx.core.graphics.PathParser.createPathFromPathData("M4 18.5A1.5 1.5 0 0 0 5.5 20H19v-3M8.5 8h6") }

private fun drawNavIcon(n: android.graphics.Canvas, kind: Int, p: android.graphics.Paint) {
    when (kind) {
        0 -> { n.drawPath(P_CHAT1, p); n.drawPath(P_CHAT2, p) }
        1 -> {
            p.pathEffect = android.graphics.DashPathEffect(floatArrayOf(3.2f, 2.4f), 0f)
            n.drawCircle(12f, 12f, 8.5f, p)
            p.pathEffect = null
            n.drawCircle(12f, 12f, 3.2f, p)
        }
        2 -> {
            n.drawCircle(12f, 8f, 2.6f, p); n.drawCircle(5.5f, 10f, 1.9f, p); n.drawCircle(18.5f, 10f, 1.9f, p)
            n.drawPath(P_COM1, p); n.drawPath(P_COM2, p); n.drawPath(P_COM3, p)
        }
        4 -> {
            n.drawPath(P_GAME, p); n.drawPath(P_GAME2, p)
            n.drawCircle(15.8f, 12.2f, 0.6f, p); n.drawCircle(18f, 14f, 0.6f, p)
        }
        5 -> { n.drawPath(P_BOOK1, p); n.drawPath(P_BOOK2, p) }
        else -> n.drawPath(P_CALL, p)
    }
}

@Composable
fun NavIcon(kind: Int, active: Boolean, ring: Float) {
    androidx.compose.foundation.Canvas(Modifier.size(28.dp)) {
        val sc = size.width / 24f
        drawIntoCanvas { c ->
            val n = c.nativeCanvas
            n.save()
            val k = if (active) 1.1f else 1f
            n.translate(size.width / 2f, size.height / 2f)
            n.scale(k, k)
            n.translate(-size.width / 2f, -size.height / 2f)
            n.scale(sc, sc)
            val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            p.style = android.graphics.Paint.Style.STROKE
            p.strokeCap = android.graphics.Paint.Cap.ROUND
            p.strokeJoin = android.graphics.Paint.Join.ROUND
            if (active) {
                p.color = NavRed.copy(alpha = 0.35f).toArgb()
                p.strokeWidth = 4.6f
                drawNavIcon(n, kind, p)
            }
            p.color = (if (active) NavRed else NavGrey).toArgb()
            p.strokeWidth = 1.8f
            drawNavIcon(n, kind, p)
            n.restore()
        }
        if (active && ring < 1f) {
            drawCircle(
                NavRed.copy(alpha = 0.9f * (1f - ring)), radius = (10.dp + 12.dp * ring).toPx(),
                center = center, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
            )
        }
    }
}

@Composable
fun NavBar(tab: Int, onTab: (Int) -> Unit, modifier: Modifier) {
    val idx by androidx.compose.animation.core.animateFloatAsState(
        tab.toFloat(),
        androidx.compose.animation.core.tween(450, easing = androidx.compose.animation.core.CubicBezierEasing(0.5f, 0f, 0.2f, 1f)),
        label = "navIdx"
    )
    val ring = remember { androidx.compose.animation.core.Animatable(1f) }
    val scope = rememberCoroutineScope()
    val labels = listOf("Chats", "Status", "Games", "Books", "Communities", "Calls")
    val kinds = listOf(0, 1, 4, 5, 2, 3)
    val n = labels.size
    Box(modifier.fillMaxWidth().height(72.dp).clip(RoundedCornerShape(28.dp)).background(Color(0xFF17181C))) {
        androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
            val w = size.width / n
            val x0 = idx * w
            val coneW = w * 0.84f
            val left = x0 + (w - coneW) / 2f
            val path = androidx.compose.ui.graphics.Path().apply {
                moveTo(left + coneW * 0.22f, 0f)
                lineTo(left + coneW * 0.78f, 0f)
                lineTo(left + coneW, size.height)
                lineTo(left, size.height)
                close()
            }
            drawPath(
                path,
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    0f to NavRed.copy(alpha = 0.55f), 0.6f to NavRed.copy(alpha = 0.12f), 1f to Color.Transparent
                )
            )
            val lw = 46.dp.toPx()
            val cx = x0 + w / 2f
            drawRoundRect(
                NavRed, androidx.compose.ui.geometry.Offset(cx - lw / 2f, 0f),
                androidx.compose.ui.geometry.Size(lw, 4.dp.toPx()),
                androidx.compose.ui.geometry.CornerRadius(6.dp.toPx())
            )
        }
        Row(Modifier.fillMaxSize()) {
            labels.forEachIndexed { i, lb ->
                Column(
                    Modifier.weight(1f).fillMaxHeight().clickable(
                        interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                        indication = null
                    ) {
                        onTab(i)
                        scope.launch { ring.snapTo(0f); ring.animateTo(1f, androidx.compose.animation.core.tween(600)) }
                    },
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                ) {
                    NavIcon(kinds[i], tab == i, ring.value)
                    Spacer(Modifier.height(5.dp))
                    Text(lb, fontSize = 10.sp, maxLines = 1, softWrap = false, color = if (tab == i) NavRed else NavGrey, fontWeight = if (tab == i) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
    }
}

// ---------- home (chat list) ----------
@Composable
fun HomeScreen(
    myId: String, isAdmin: Boolean,
    onOpen: (String, String) -> Unit, onProfile: () -> Unit, onAdmin: () -> Unit, onLogout: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var friends by remember { mutableStateOf<List<Friend>>(emptyList()) }
    var globalBlocked by remember { mutableStateOf<Set<String>>(emptySet()) }
    var wall by remember { mutableStateOf<Wall?>(null) }
    DisposableEffect(myId) {
        val a = Repo.listenFriends { friends = it }
        val b = Repo.listenGlobalBlocked { globalBlocked = it }
        val c = Repo.listenWall("bg_home") { wall = it }
        onDispose { a?.remove(); b.remove(); c.remove() }
    }
    LaunchedEffect(friends) {
        friends.filter { it.unread > 0 && it.lastBy != myId }.forEach { Repo.markDelivered(it.id) }
    }
    val wf = remember { WallFlow() }
    WallpaperHost(wf)
    val me = Repo.profiles[myId]
    var menu by remember { mutableStateOf("") }
    var diagText by remember { mutableStateOf<String?>(null) }
    var peek by remember { mutableStateOf<Pair<String, String>?>(null) }
    var q by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    val focusMgr = LocalFocusManager.current
    val searchFocus = remember { FocusRequester() }
    var searchHadFocus by remember { mutableStateOf(false) }
    LaunchedEffect(showSearch) { if (showSearch) { searchHadFocus = false; try { searchFocus.requestFocus() } catch (e: Exception) {} } }
    val lsp = remember { ctx.getSharedPreferences("reader", android.content.Context.MODE_PRIVATE) }
    var light by remember { mutableStateOf(lsp.getBoolean("listLight", true)) }
    val nameC = if (light) Color(0xFF1B2733) else Color.White
    val subC = if (light) Color(0xFF3F4A59) else Muted
    var note by remember { mutableStateOf("") }
    var found by remember { mutableStateOf<Pair<String, Prof>?>(null) }
    LaunchedEffect(q) { if (q.isBlank()) { found = null; note = "" } }

    Box(Modifier.fillMaxSize()) {
        val hw = wall
        if (hw != null && !hw.none && hw.src.isNotBlank()) WallBg(hw) else if (light) CatBg()
        Column(
            Modifier.fillMaxSize().systemBarsPadding().pointerInput(showSearch) {
                detectTapGestures { if (showSearch && q.isBlank()) { showSearch = false; focusMgr.clearFocus() } }
            }
        ) {
            Row(
                Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Chatzo", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Box(Modifier.size(40.dp).clickable { light = !light; lsp.edit().putBoolean("listLight", light).apply() }, contentAlignment = Alignment.Center) {
                    LineIcon(I_CONTRAST, if (light) Color.White else Color(0xFF6B7280), 24)
                }
                Box(Modifier.size(40.dp).clickable { showSearch = !showSearch; if (!showSearch) { q = ""; note = ""; found = null } }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Search, null, tint = Color.White, modifier = Modifier.size(26.dp))
                }
                Spacer(Modifier.width(8.dp))
                Avatar(me?.name ?: "Me", me?.photo ?: "", 38, Modifier.clickable { onProfile() }, person = true)
                Spacer(Modifier.width(14.dp))
                Box {
                    GearIcon(Modifier.clickable { menu = "main" })
                    DropdownMenu(menu != "", { menu = "" }) {
                        if (menu == "wp") {
                            DropdownMenuItem(text = { Text("Change background") }, onClick = { menu = ""; wf.start("bg_home") })
                            DropdownMenuItem(text = { Text("Remove background") }, onClick = {
                                menu = ""
                                scope.launch { Repo.removeWall("bg_home", false) }
                            })
                        } else {
                            DropdownMenuItem(text = { Text("Wallpaper") }, onClick = { menu = "wp" })
                            DropdownMenuItem(text = { Text("Notification check") }, onClick = {
                                menu = ""
                                diagText = "Checking…"
                                scope.launch { diagText = Repo.diag(ctx) }
                            })
                            if (isAdmin) DropdownMenuItem(text = { Text("Admin: users") }, onClick = { menu = ""; onAdmin() })
                            DropdownMenuItem(text = { Text("Log out") }, onClick = { menu = ""; onLogout() })
                            HorizontalDivider()
                            Text("Settings", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                        }
                    }
                }
            }
            diagText?.let { t ->
                AlertDialog(
                    onDismissRequest = { diagText = null },
                    title = { Text("Notification check") },
                    text = { Text(t) },
                    confirmButton = { TextButton(onClick = { diagText = null }) { Text("Close") } }
                )
            }
            peek?.let { (n, ph) -> PeekDialog(n, ph) { peek = null } }
            if (showSearch) OutlinedTextField(
                q, { q = it }, singleLine = true,
                placeholder = { Text("Search by phone number") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = {
                    val ph = Repo.normPhone(q)
                    if (ph.length < 10) { note = "Enter a valid phone number"; found = null }
                    else searching = true
                }),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
                    .focusRequester(searchFocus)
                    .onFocusChanged {
                        if (it.isFocused) searchHadFocus = true
                        else if (searchHadFocus && q.isBlank()) { showSearch = false; searchHadFocus = false }
                    }
            )
            if (searching) {
                LaunchedEffect(Unit) {
                    val ph = Repo.normPhone(q)
                    try {
                        val r = Repo.searchPhone(ph)
                        when {
                            r == null -> { found = null; note = "No one found with this number." }
                            r.first == myId -> { found = null; note = "That's your own number." }
                            globalBlocked.contains(r.first) -> { found = null; note = "This user is not available." }
                            else -> { found = r; note = "" }
                        }
                    } catch (e: Exception) { found = null; note = "Couldn't search: " + (e.message ?: "") }
                    searching = false
                }
            }
            if (note.isNotBlank()) Text(note, color = Muted, modifier = Modifier.padding(16.dp))
            found?.let { (uid, p) ->
                Row(
                    Modifier.fillMaxWidth().background(Panel).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(p.name, p.photo, 46)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name.ifBlank { "User" }, color = Color.White, fontSize = 16.sp)
                        Text(if (p.phone.isNotBlank()) "+" + p.phone else "", color = Muted, fontSize = 13.sp)
                    }
                    Button(onClick = { q = ""; onOpen(uid, p.name.ifBlank { "User" }) }) { Text("Message") }
                }
            }
            val list = friends.filter { !globalBlocked.contains(it.id) }.sortedByDescending { it.lastAt }
            if (list.isEmpty()) {
                Text(
                    "No chats yet. Search a phone number above to find someone and send a message.",
                    color = subC, modifier = Modifier.padding(24.dp)
                )
            }
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 108.dp)) {
                items(list, key = { it.id }) { f ->
                    val p = Repo.profile(f.id)
                    val name = p?.name?.ifBlank { null } ?: f.name.ifBlank { "Friend" }
                    Row(
                        Modifier.fillMaxWidth().clickable { onOpen(f.id, name) }.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(name, p?.photo ?: "", 52, Modifier.clickable { peek = name to (p?.photo ?: "") })
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Row {
                                Text(name, color = nameC, fontSize = 17.sp, fontWeight = FontWeight.Medium,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                Text(stamp(f.lastAt), color = if (f.unread > 0) (if (light) Color(0xFF0E7A6B) else TealLight) else subC, fontSize = 12.sp)
                            }
                            Spacer(Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (f.lastBy == myId && f.lastText.isNotBlank() && f.lastText != "You deleted this message" && f.lastText != "This message was deleted") { Ticks(f.lastSt.ifBlank { "delivered" }); Spacer(Modifier.width(4.dp)) }
                                Text(f.lastText.ifBlank { p?.bio ?: "" }, color = subC, fontSize = 14.sp, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                if (f.unread > 0) {
                                    Box(Modifier.clip(CircleShape).background(TealLight).defaultMinSize(22.dp, 22.dp).padding(horizontal = 6.dp),
                                        contentAlignment = Alignment.Center) {
                                        Text(if (f.unread > 99) "99+" else f.unread.toString(), color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------- chat ----------
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatScreen(myId: String, otherId: String, otherName: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    var msgs by remember { mutableStateOf<List<Msg>>(emptyList()) }
    var on by remember { mutableStateOf(false) }
    var seenAt by remember { mutableStateOf(0L) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var text by remember { mutableStateOf("") }
    var viewer by remember { mutableStateOf<Bitmap?>(null) }
    var menuMsg by remember { mutableStateOf<Msg?>(null) }
    var sel by remember { mutableStateOf<Msg?>(null) }
    var showAttach by remember { mutableStateOf(false) }
    val imeBottom = WindowInsets.ime.getBottom(androidx.compose.ui.platform.LocalDensity.current)
    SideEffect { if (imeBottom > 200) Kb.px = imeBottom }
    var replyTo by remember { mutableStateOf<Msg?>(null) }
    fun snip(m: Msg) = if (m.img.isNotBlank() && m.text.isBlank()) "📷 Photo" else m.text.take(100)
    var err by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf("") }
    var askBlock by remember { mutableStateOf(false) }
    var askReport by remember { mutableStateOf(false) }
    var emoji by remember { mutableStateOf(false) }
    var peek by remember { mutableStateOf(false) }
    var showProf by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    var myBlocks by remember { mutableStateOf<Set<String>>(emptySet()) }
    var wallChat by remember { mutableStateOf<Wall?>(null) }
    var wallAll by remember { mutableStateOf<Wall?>(null) }
    val cid = remember { Repo.chatId(myId, otherId) }
    val p = Repo.profile(otherId)
    val name = p?.name?.ifBlank { null } ?: otherName
    val blockedByMe = myBlocks.contains(otherId)
    val wf = remember { WallFlow() }
    WallpaperHost(wf)

    DisposableEffect(cid) {
        val a = Repo.listenMessages(cid) { msgs = it }
        val b = Repo.listenPresence(otherId) { o, t -> on = o; seenAt = t }
        val c = Repo.listenMyBlocks { myBlocks = it }
        val d = Repo.listenWall("bg_$otherId") { wallChat = it }
        val e = Repo.listenWall("bg_all") { wallAll = it }
        onDispose { a.remove(); b.remove(); c.remove(); d.remove(); e.remove() }
    }
    LaunchedEffect(otherId) {
        try { (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(otherId.hashCode()) } catch (e: Exception) {}
    }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(20000) } }
    LaunchedEffect(msgs.lastOrNull()?.id) {
        val last = msgs.lastOrNull()
        if (last != null && (last.uid == myId || listState.firstVisibleItemIndex <= 2)) listState.animateScrollToItem(0)
    }
    LaunchedEffect(msgs.lastOrNull()?.id, msgs.lastOrNull()?.st) {
        val l = msgs.lastOrNull()
        if (l != null && l.uid == myId && !l.deleted) Repo.syncLastSt(otherId, l.st)
    }
    LaunchedEffect(msgs) {
        val un = msgs.filter { it.uid != myId && !it.deleted && it.st != "read" }.map { it.id }
        Repo.markRead(otherId, un)
    }

    fun sendUri(uri: Uri) {
        scope.launch {
            val d = withContext(Dispatchers.IO) { Repo.readPhoto(ctx, uri, 1280, 700000) }
            if (d == null) err = "Couldn't use that photo." else {
                val r = replyTo
                replyTo = null
                Repo.sendImage(otherId, name, d, if (r != null) snip(r) else "", r?.uid ?: "")?.let { err = it }
            }
        }
    }
    fun sendMany(uris: List<Uri>, cap: String) {
        scope.launch {
            val r = replyTo
            replyTo = null
            uris.forEachIndexed { i, u ->
                val d = withContext(Dispatchers.IO) { Repo.readPhoto(ctx, u, 1280, 700000) }
                if (d == null) err = "Couldn't use one photo."
                else Repo.sendImage(otherId, name, d, if (i == 0 && r != null) snip(r) else "", if (i == 0) (r?.uid ?: "") else "", if (i == 0) cap else "")?.let { err = it }
            }
        }
    }
    val pickerMulti = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(10)) { uris -> if (uris.isNotEmpty()) sendMany(uris, "") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) sendUri(uri) }
    var camUri by remember { mutableStateOf<Uri?>(null) }
    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = camUri
        if (ok && u != null) sendUri(u)
    }
    val status = when {
        on && now - seenAt < 90000 -> "online"
        seenAt > 0 -> "last seen " + lastSeen(seenAt)
        else -> ""
    }
    val eff: Wall? = if (wallChat != null) (if (wallChat!!.none) null else wallChat) else (if (wallAll?.none == true) null else wallAll)

    Box(Modifier.fillMaxSize().background(Bg)) {
        WallBg(eff, true)
        Box(Modifier.align(Alignment.TopStart).fillMaxWidth().windowInsetsTopHeight(WindowInsets.statusBars).background(Bar))
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            val selNow = sel
            if (selNow != null) {
                val clip = androidx.compose.ui.platform.LocalClipboardManager.current
                Row(Modifier.fillMaxWidth().background(Bar).height(60.dp).padding(end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { sel = null }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
                    Text("1", color = Color.White, fontSize = 18.sp, modifier = Modifier.weight(1f))
                    Box(Modifier.size(48.dp).clickable { replyTo = selNow; sel = null }, contentAlignment = Alignment.Center) { Text("↩", color = Color.White, fontSize = 24.sp) }
                    if (selNow.text.isNotBlank()) Box(Modifier.size(48.dp).clickable {
                        clip.setText(androidx.compose.ui.text.AnnotatedString(selNow.text)); sel = null
                    }, contentAlignment = Alignment.Center) { Text("⧉", color = Color.White, fontSize = 22.sp) }
                    if (selNow.uid == myId) Box(Modifier.size(48.dp).clickable {
                        val d = selNow; sel = null
                        scope.launch { Repo.deleteMsg(otherId, d.id)?.let { err = it } }
                    }, contentAlignment = Alignment.Center) { Text("🗑", fontSize = 21.sp) }
                }
            } else {
            Row(
                Modifier.fillMaxWidth().background(Bar).height(60.dp).padding(end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
                Avatar(name, p?.photo ?: "", 40, Modifier.clickable { peek = true })
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f).clickable { showProf = true }) {
                    Text(name, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (status.isNotBlank()) Text(status, color = if (status == "online") TealLight else Muted, fontSize = 12.sp)
                }
                Box {
                    IconButton(onClick = { menu = "main" }) { Icon(Icons.Default.MoreVert, null, tint = Color.White) }
                    DropdownMenu(menu != "", { menu = "" }) {
                        if (menu == "wp") {
                            DropdownMenuItem(text = { Text("Change background") }, onClick = { menu = ""; wf.start("bg_$otherId") })
                            DropdownMenuItem(text = { Text("Change for all chats") }, onClick = { menu = ""; wf.start("bg_all") })
                            DropdownMenuItem(text = { Text("Remove background") }, onClick = {
                                menu = ""
                                scope.launch { Repo.removeWall("bg_$otherId", wallAll != null && wallAll?.none != true) }
                            })
                        } else {
                            DropdownMenuItem(text = { Text("Wallpaper") }, onClick = { menu = "wp" })
                        }
                    }
                }
            }
            }
            val rev = remember(msgs) { msgs.asReversed() }
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, reverseLayout = true, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)) {
                itemsIndexed(rev, key = { _, it -> it.id }) { i, m ->
                    val mine = m.uid == myId
                    val big = !m.deleted && m.img.isBlank() && isEmojiOnly(m.text)
                    val firstOfDay = i == rev.lastIndex || dayKey(rev[i + 1].at) != dayKey(m.at)
                    Column(Modifier.fillMaxWidth()) {
                    if (firstOfDay) {
                        Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                            Text(dayLabel(m.at), color = Muted, fontSize = 12.sp,
                                modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(InBubble).padding(horizontal = 10.dp, vertical = 4.dp))
                        }
                    }
                    var dx by remember { mutableFloatStateOf(0f) }
                    val trig = with(androidx.compose.ui.platform.LocalDensity.current) { 64.dp.toPx() }
                    Box(Modifier.fillMaxWidth().background(if (sel?.id == m.id) Color(0x4400BFA5) else Color.Transparent)) {
                    if (dx > 20f) Text("↩", color = TealLight, fontSize = 22.sp, modifier = Modifier.align(Alignment.CenterStart).padding(start = 12.dp))
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 1.dp)
                            .offset { androidx.compose.ui.unit.IntOffset(dx.toInt(), 0) }
                            .pointerInput(m.id) {
                                detectHorizontalDragGestures(
                                    onDragEnd = { if (dx > trig && !m.deleted) replyTo = m; dx = 0f },
                                    onDragCancel = { dx = 0f }
                                ) { _, a -> dx = (dx + a).coerceIn(0f, trig * 1.3f) }
                            },
                        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
                    ) {
                        Column(
                            Modifier.widthIn(max = 290.dp).clip(RoundedCornerShape(12.dp))
                                .background(if (big) Color.Transparent else if (mine) OutBubble else InBubble)
                                .combinedClickable(onClick = {
                                    if (sel != null) sel = null
                                    else if (m.img.isNotBlank() && !m.deleted) viewer = Repo.decodeDataUrl(m.img)
                                }, onLongClick = { if (!m.deleted) sel = m })
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            if (!m.deleted && m.rt.isNotBlank()) Row(
                                Modifier.padding(bottom = 4.dp).clip(RoundedCornerShape(6.dp)).background(Color(0x33000000)).height(IntrinsicSize.Min)
                            ) {
                                Box(Modifier.width(4.dp).fillMaxHeight().background(TealLight))
                                Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                                    Text(if (m.ru == myId) "You" else name, color = TealLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text(m.rt, color = Color(0xCCFFFFFF), fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            if (m.deleted) {
                                Row(verticalAlignment = Alignment.Bottom) {
                                    BlockIcon()
                                    Spacer(Modifier.width(6.dp))
                                    Text(if (mine) "You deleted this message" else "This message was deleted",
                                        color = Color(0xFFA7B5BB), fontSize = 15.sp, fontStyle = FontStyle.Italic,
                                        modifier = Modifier.weight(1f, fill = false))
                                    Spacer(Modifier.width(10.dp))
                                    Text(hm(m.at), color = Muted, fontSize = 11.sp)
                                }
                            } else if (m.img.isNotBlank()) {
                                val b = rememberBitmap(m.img)
                                if (b != null) Image(b, null, Modifier.width(240.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.FillWidth)
                                else Box(Modifier.size(240.dp, 160.dp).background(Bar))
                                if (m.text.isNotBlank()) Text(m.text, color = Color.White, fontSize = 16.sp)
                                Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                                    Text(hm(m.at), color = Muted, fontSize = 11.sp)
                                    if (mine) { Spacer(Modifier.width(4.dp)); Ticks(m.st) }
                                }
                            } else if (big) {
                                if (glossKind(m.text.trim()) != null) GlossEmoji(m.text.trim(), 72.dp)
                                else Text(m.text.trim(), fontSize = if (emojiCount(m.text) == 1) 56.sp else 40.sp)
                                Row(
                                    Modifier.align(Alignment.End).clip(RoundedCornerShape(10.dp)).background(if (mine) OutBubble else InBubble)
                                        .padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(hm(m.at), color = Muted, fontSize = 11.sp)
                                    if (mine) { Spacer(Modifier.width(4.dp)); Ticks(m.st) }
                                }
                            } else {
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(m.text, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f, fill = false))
                                    Spacer(Modifier.width(10.dp))
                                    Text(hm(m.at), color = Muted, fontSize = 11.sp)
                                    if (mine) { Spacer(Modifier.width(4.dp)); Ticks(m.st) }
                                }
                            }
                        }
                    }
                    }
                    }
                }
            }
            if (err.isNotBlank()) Text(err, color = Red, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp))
            if (blockedByMe) {
                Text(
                    "You blocked this contact. Use the menu to unblock.",
                    color = Muted, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().background(Bar).padding(16.dp)
                )
            } else {
                replyTo?.let { r ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp).clip(RoundedCornerShape(12.dp)).background(Bar).height(IntrinsicSize.Min)) {
                        Box(Modifier.width(4.dp).fillMaxHeight().background(TealLight))
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 6.dp)) {
                            Text(if (r.uid == myId) "You" else name, color = TealLight, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(snip(r), color = Muted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Box(Modifier.size(44.dp).clickable { replyTo = null }, contentAlignment = Alignment.Center) { Text("✕", color = Muted, fontSize = 16.sp) }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.Bottom) {
                    Row(
                        Modifier.weight(1f).clip(RoundedCornerShape(26.dp)).background(Bar),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Box(Modifier.size(46.dp, 52.dp).clickable {
                            focus.clearFocus()
                            showAttach = false
                            emoji = !emoji
                        }, contentAlignment = Alignment.Center) { LineIcon(I_SMILE, Color(0xFFB8C4CB), 25) }
                        TextField(
                            text, { text = it }, placeholder = { Text("Message", color = Muted) }, maxLines = 5,
                            keyboardOptions = KeyboardOptions(capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.Sentences),
                            modifier = Modifier.weight(1f).onFocusChanged { if (it.isFocused) { emoji = false; showAttach = false } },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                                cursorColor = TealLight
                            )
                        )
                        Box(Modifier.size(44.dp, 52.dp).clickable { focus.clearFocus(); emoji = false; showAttach = !showAttach }, contentAlignment = Alignment.Center) {
                            LineIcon(I_CLIP, Color(0xFFB8C4CB), 24)
                        }
                        Box(Modifier.size(44.dp, 52.dp).clickable {
                            try {
                                val f = File(ctx.cacheDir, "cam_" + System.currentTimeMillis() + ".jpg")
                                val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
                                camUri = u
                                cam.launch(u)
                            } catch (e: Exception) { err = "Camera not available" }
                        }, contentAlignment = Alignment.Center) { LineIcon(I_CAMERA, Color(0xFFB8C4CB), 25) }
                    }
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier.size(52.dp).clip(CircleShape).background(Teal).clickable {
                            val t = text.trim()
                            if (t.isNotEmpty()) {
                                text = ""
                                val r = replyTo
                                replyTo = null
                                scope.launch { Repo.sendText(otherId, name, t, if (r != null) snip(r) else "", r?.uid ?: "")?.let { err = it; text = t; replyTo = r } }
                            } else Toast.makeText(ctx, "Voice messages are coming soon", Toast.LENGTH_SHORT).show()
                        }, contentAlignment = Alignment.Center
                    ) { if (text.isBlank()) LineIcon(I_MIC, Color.White, 26) else Icon(Icons.AutoMirrored.Filled.Send, null, tint = Color.White) }
                }
                if (emoji) EmojiPanel(onPick = { text += it }, onDelete = { text = dropLastChar(text) })
                if (showAttach) AttachSheet(
                onDismiss = { showAttach = false },
                onCamera = {
                    try {
                        val f = File(ctx.cacheDir, "cam_" + System.currentTimeMillis() + ".jpg")
                        val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
                        camUri = u
                        cam.launch(u)
                    } catch (e: Exception) { err = "Camera not available" }
                },
                onPickSystem = { pickerMulti.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                onSoon = { what ->
                    Toast.makeText(ctx, if (what == "max10") "You can send up to 10 photos at once" else "$what is coming soon", Toast.LENGTH_SHORT).show()
                },
                onSend = { l, c -> sendMany(l, c) }
            )
            }
        }
    }

    menuMsg?.let { m ->
        val clip = androidx.compose.ui.platform.LocalClipboardManager.current
        AlertDialog(
            onDismissRequest = { menuMsg = null },
            confirmButton = {
                Column {
                    if (m.text.isNotBlank()) TextButton(onClick = { clip.setText(androidx.compose.ui.text.AnnotatedString(m.text)); menuMsg = null }) { Text("Copy") }
                    if (m.uid == myId) TextButton(onClick = {
                        menuMsg = null
                        scope.launch { Repo.deleteMsg(otherId, m.id)?.let { err = it } }
                    }) { Text("Delete for everyone", color = Red) }
                    TextButton(onClick = { menuMsg = null }) { Text("Cancel") }
                }
            }
        )
    }
    if (askBlock) {
        AlertDialog(
            onDismissRequest = { askBlock = false },
            title = { Text("Block $name?") },
            text = { Text("They will not be able to message you.") },
            confirmButton = {
                TextButton(onClick = {
                    askBlock = false
                    scope.launch {
                        val r = Repo.setBlock(otherId, true)
                        Toast.makeText(ctx, r ?: "Contact blocked", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Block", color = Red) }
            },
            dismissButton = { TextButton(onClick = { askBlock = false }) { Text("Cancel") } }
        )
    }
    if (askReport) {
        AlertDialog(
            onDismissRequest = { askReport = false },
            title = { Text("Report $name") },
            confirmButton = {
                Column {
                    listOf("Spam", "Abuse or harassment", "Inappropriate content", "Other").forEach { r ->
                        TextButton(onClick = {
                            askReport = false
                            scope.launch {
                                val x = Repo.report(otherId, r)
                                Toast.makeText(ctx, x ?: "Report sent to the admin", Toast.LENGTH_SHORT).show()
                            }
                        }) { Text(r) }
                    }
                    TextButton(onClick = { askReport = false }) { Text("Cancel", color = Muted) }
                }
            }
        )
    }
    if (showProf) {
        Dialog(onDismissRequest = { showProf = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding()) {
                Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { showProf = false }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
                    Text("Contact info", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                }
                Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(Modifier.height(16.dp))
                    Avatar(name, p?.photo ?: "", 140, Modifier.clickable { peek = true }, person = true)
                    Spacer(Modifier.height(14.dp))
                    Text(name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                    if (status.isNotBlank()) Text(status, color = if (status == "online") TealLight else Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(20.dp))
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(14.dp)).background(Panel).padding(16.dp)) {
                        Text("About", color = Muted, fontSize = 12.sp)
                        Text(p?.bio?.ifBlank { null } ?: "Hey there! I am using Chatzo.", color = Color.White, fontSize = 16.sp)
                        Spacer(Modifier.height(14.dp))
                        Text("Phone", color = Muted, fontSize = 12.sp)
                        Text(p?.phone?.ifBlank { null } ?: "—", color = Color.White, fontSize = 16.sp)
                    }
                    Spacer(Modifier.height(16.dp))
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(14.dp)).background(Panel)) {
                        Text(if (blockedByMe) "Unblock $name" else "Block $name", color = Red, fontSize = 16.sp,
                            modifier = Modifier.fillMaxWidth().clickable {
                                if (blockedByMe) scope.launch { Repo.setBlock(otherId, false)?.let { err = it } } else askBlock = true
                            }.padding(16.dp))
                        Text("Report $name", color = Red, fontSize = 16.sp,
                            modifier = Modifier.fillMaxWidth().clickable { askReport = true }.padding(16.dp))
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
    if (peek) PeekDialog(name, p?.photo ?: "") { peek = false }
    viewer?.let { PhotoViewer(it) { viewer = null } }
}

// ---------- my profile ----------
@Composable
fun ProfileScreen(myId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val me = Repo.profiles[myId] ?: Prof()
    var name by remember { mutableStateOf(me.name) }
    var bio by remember { mutableStateOf(me.bio) }
    var phone by remember { mutableStateOf("") }
    var src by remember { mutableStateOf<Bitmap?>(null) }
    var z by remember { mutableFloatStateOf(1f) }
    var px by remember { mutableFloatStateOf(0.5f) }
    var py by remember { mutableFloatStateOf(0.5f) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val b = withContext(Dispatchers.IO) { Repo.loadBitmap(ctx, uri, 1024) }
            if (b != null) { src = b; z = 1f; px = 0.5f; py = 0.5f } else msg = "Couldn't use that photo."
        }
    }
    val cropped = remember(src, z, px, py) { src?.let { cropSquare(it, z, px, py, 320) } }
    Column(
        Modifier.fillMaxSize().background(Bg).windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Row(Modifier.fillMaxWidth().background(Bar).height(60.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
            Text("My profile", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Medium)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (cropped != null) {
                Box(Modifier.size(120.dp).clip(CircleShape)) { Image(cropped.asImageBitmap(), null, Modifier.fillMaxSize()) }
            } else Avatar(name.ifBlank { me.name }, me.photo, 120)
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("Change photo") }
            if (src != null) {
                Text("Zoom", color = Muted, fontSize = 13.sp)
                Slider(z, { z = it }, valueRange = 1f..3f)
                Text("Left – right", color = Muted, fontSize = 13.sp)
                Slider(px, { px = it }, valueRange = 0f..1f)
                Text("Up – down", color = Muted, fontSize = 13.sp)
                Slider(py, { py = it }, valueRange = 0f..1f)
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(name, { if (it.length <= 40) name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(bio, { if (it.length <= 140) bio = it }, label = { Text("Bio") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            if (me.phone.isNotBlank()) {
                Text("Phone: +" + me.phone, color = Muted, modifier = Modifier.align(Alignment.Start))
            } else {
                OutlinedTextField(
                    phone, { phone = it.filter { c -> c.isDigit() || c == '+' || c == ' ' } },
                    label = { Text("Phone number") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            }
            if (msg.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(msg, color = if (msg == "Profile saved.") TealLight else Red) }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    val n = name.trim()
                    if (n.isEmpty()) { msg = "Name can't be empty"; return@Button }
                    val ph = Repo.normPhone(phone)
                    if (phone.isNotBlank() && ph.length < 10) { msg = "Enter a valid phone number"; return@Button }
                    busy = true; msg = ""
                    scope.launch {
                        val photo = cropped?.let { Repo.toDataUrl(it, 85) }
                        val r = Repo.saveProfile(n, bio.trim(), photo, if (phone.isBlank()) null else ph)
                        busy = false
                        if (r == null) { msg = "Profile saved."; src = null } else msg = r
                    }
                },
                enabled = !busy, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(25.dp)
            ) { Text(if (busy) "Saving…" else "Save profile") }
        }
    }
}

// ---------- admin ----------
@Composable
fun AdminScreen(myId: String, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var users by remember { mutableStateOf<List<AdminUser>>(emptyList()) }
    var reports by remember { mutableStateOf<List<Report>>(emptyList()) }
    var blocked by remember { mutableStateOf<Set<String>>(emptySet()) }
    var loading by remember { mutableStateOf(true) }
    var err by remember { mutableStateOf("") }
    DisposableEffect(Unit) {
        val l = Repo.listenGlobalBlocked { blocked = it }
        onDispose { l.remove() }
    }
    LaunchedEffect(Unit) {
        try { users = Repo.adminUsers(); reports = Repo.adminReports() } catch (e: Exception) { err = e.message ?: "Error" }
        loading = false
    }
    val nameOf = { id: String -> users.firstOrNull { it.id == id }?.name?.ifBlank { null } ?: id.take(6) }
    Column(Modifier.fillMaxSize().background(Bg).windowInsetsPadding(WindowInsets.safeDrawing)) {
        Row(Modifier.fillMaxWidth().background(Bar).height(60.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
            Text("Admin: users", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Medium)
        }
        if (loading) Text("Loading…", color = Muted, modifier = Modifier.padding(16.dp))
        if (err.isNotBlank()) Text(err, color = Red, modifier = Modifier.padding(16.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            if (reports.isNotEmpty()) {
                item { Text("Reports", color = TealLight, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp, 12.dp, 16.dp, 4.dp)) }
                items(reports, key = { "r" + it.id }) { r ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(nameOf(r.against), color = Color.White)
                            Text("Reported by " + nameOf(r.by) + ": " + r.reason, color = Muted, fontSize = 13.sp)
                        }
                        val on = blocked.contains(r.against)
                        TextButton(onClick = { scope.launch { Repo.setGlobalBlock(r.against, !on) } }) {
                            Text(if (on) "Unblock" else "Block", color = if (on) TealLight else Red)
                        }
                    }
                }
            }
            item { Text("Users", color = TealLight, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 4.dp)) }
            items(users, key = { "u" + it.id }) { u ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(u.name.ifBlank { "(no name)" }, color = Color.White)
                        Text((if (u.phone.isNotBlank()) "+" + u.phone + "  " else "") + u.email, color = Muted, fontSize = 13.sp)
                    }
                    if (u.id != myId) {
                        val on = blocked.contains(u.id)
                        TextButton(onClick = { scope.launch { Repo.setGlobalBlock(u.id, !on) } }) {
                            Text(if (on) "Unblock" else "Block", color = if (on) TealLight else Red)
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun GearIcon(modifier: Modifier = Modifier) {
    androidx.compose.foundation.Canvas(modifier.size(38.dp)) {
        val c = center
        val st = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.9.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
        val r = size.minDimension * 0.24f
        drawCircle(Color.White, r, c, style = st)
        drawCircle(Color.White, size.minDimension * 0.09f, c, style = st)
        for (i in 0 until 8) {
            val a = Math.toRadians(i * 45.0)
            val dx = Math.cos(a).toFloat(); val dy = Math.sin(a).toFloat()
            drawLine(Color.White,
                androidx.compose.ui.geometry.Offset(c.x + dx * r, c.y + dy * r),
                androidx.compose.ui.geometry.Offset(c.x + dx * r * 1.55f, c.y + dy * r * 1.55f),
                strokeWidth = 2.6.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
        }
    }
}


fun dayKey(t: Long): String = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.getDefault()).format(java.util.Date(t))
fun dayLabel(t: Long): String {
    val d = dayKey(t)
    val now = System.currentTimeMillis()
    if (d == dayKey(now)) return "Today"
    if (d == dayKey(now - 86400000L)) return "Yesterday"
    for (k in 2..6) if (d == dayKey(now - k * 86400000L))
        return java.text.SimpleDateFormat("EEEE", java.util.Locale.ENGLISH).format(java.util.Date(t))
    return java.text.SimpleDateFormat("d MMMM yyyy", java.util.Locale.getDefault()).format(java.util.Date(t))
}

@Composable
fun BlockIcon() {
    androidx.compose.foundation.Canvas(Modifier.size(18.dp).padding(bottom = 2.dp)) {
        val c = Color(0xFFA7B5BB)
        val st = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.6.dp.toPx())
        val r = size.minDimension / 2f - 1.dp.toPx()
        drawCircle(c, r, center, style = st)
        val k = r * 0.7071f
        drawLine(c, androidx.compose.ui.geometry.Offset(center.x - k, center.y + k),
            androidx.compose.ui.geometry.Offset(center.x + k, center.y - k), strokeWidth = 1.6.dp.toPx())
    }
}


fun dropLastChar(t: String): String {
    if (t.isEmpty()) return t
    val it = java.text.BreakIterator.getCharacterInstance()
    it.setText(t)
    val last = it.last()
    val prev = it.preceding(last)
    return if (prev < 0) "" else t.substring(0, prev)
}

@Composable
fun EmojiPanel(onPick: (String) -> Unit, onDelete: () -> Unit) {
    var cat by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxWidth().background(Bar)) {
        Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
            EMOJI_TABS.forEachIndexed { i, ic ->
                Box(
                    Modifier.weight(1f).fillMaxHeight().clickable { cat = i },
                    contentAlignment = Alignment.Center
                ) {
                    Text(ic, fontSize = if (cat == i) 24.sp else 20.sp)
                    if (cat == i) Box(Modifier.align(Alignment.BottomCenter).width(24.dp).height(3.dp).background(TealLight))
                }
            }
            Box(Modifier.size(44.dp).clickable { onDelete() }, contentAlignment = Alignment.Center) {
                Text("⌫", fontSize = 22.sp, color = Color.White)
            }
        }
        Text(if (cat == 0) "3D picks" else EMOJI_NAMES[cat], color = Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 12.dp, top = 2.dp))
        if (cat == 0) LazyRow(Modifier.fillMaxWidth().height(58.dp), contentPadding = PaddingValues(horizontal = 6.dp)) {
            val picks = GLOSS_KIND.keys.toList()
            items(picks) { e ->
                Box(Modifier.size(54.dp).clickable { onPick(e) }, contentAlignment = Alignment.Center) { GlossEmoji(e, 42.dp) }
            }
        }
        LazyVerticalGrid(
            GridCells.Fixed(8), Modifier.fillMaxWidth().height(250.dp),
            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
        ) {
            gridItems(EMOJI_SETS[cat]) { e ->
                Box(Modifier.height(46.dp).clickable { onPick(e) }, contentAlignment = Alignment.Center) {
                    Text(e, fontSize = 29.sp)
                }
            }
        }
    }
}


fun emojiCount(t: String): Int {
    val it = java.text.BreakIterator.getCharacterInstance()
    it.setText(t.trim())
    var n = 0
    while (it.next() != java.text.BreakIterator.DONE) n++
    return n
}

/** true when a message is only 1-3 emoji (no letters, digits or spaces) */
fun isEmojiOnly(t: String): Boolean {
    val x = t.trim()
    if (x.isEmpty() || x.length > 30) return false
    var i = 0
    while (i < x.length) {
        val cp = x.codePointAt(i)
        if (Character.isLetterOrDigit(cp) || Character.isWhitespace(cp) || cp < 0x203C) return false
        i += Character.charCount(cp)
    }
    return emojiCount(x) in 1..3
}
