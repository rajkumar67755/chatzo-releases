package rm.chatzo.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.launch

/** Full-screen "update required" page. Nothing else in the app opens until the update is installed. */
@Composable
fun UpdateScreen(name: String, url: String, note: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var prog by remember { mutableIntStateOf(-1) }
    var msg by remember { mutableStateOf("") }

    fun install(f: java.io.File) {
        try {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
            msg = "Couldn't open the installer."
        }
    }

    fun start() {
        if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
            msg = "Turn on \"Allow from this source\" for Chatzo, then come back and press New version again."
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {}
            return
        }
        msg = ""
        scope.launch {
            prog = 0
            val f = Repo.downloadApk(ctx, url) { prog = it }
            if (f == null) {
                prog = -1
                msg = "Download failed. Check your internet and try again."
            } else {
                prog = -1
                install(f)
            }
        }
    }

    Column(
        Modifier.fillMaxSize().background(Bg).systemBarsPadding().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Update required", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(
            "A new version of Chatzo" + (if (name.isNotBlank()) " ($name)" else "") + " is available. Please update to continue.",
            color = Muted, fontSize = 15.sp, textAlign = TextAlign.Center
        )
        if (note.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(note, color = Color.White, fontSize = 14.sp, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(28.dp))
        if (prog >= 0) {
            LinearProgressIndicator(progress = { prog / 100f }, modifier = Modifier.fillMaxWidth(), color = Teal)
            Spacer(Modifier.height(10.dp))
            Text("Downloading $prog%", color = Muted, fontSize = 13.sp)
        } else {
            Button(
                onClick = { start() },
                colors = ButtonDefaults.buttonColors(containerColor = Teal, contentColor = Color.White),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) { Text("New version", fontSize = 16.sp) }
        }
        if (msg.isNotBlank()) {
            Spacer(Modifier.height(14.dp))
            Text(msg, color = Red, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
    }
}


/** Installs through the system installer session: one confirm tap, then the app reopens by itself. */
fun installApk(ctx: android.content.Context, f: java.io.File) {
    val pi = ctx.packageManager.packageInstaller
    val params = android.content.pm.PackageInstaller.SessionParams(android.content.pm.PackageInstaller.SessionParams.MODE_FULL_INSTALL)
    if (Build.VERSION.SDK_INT >= 31) params.setRequireUserAction(android.content.pm.PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
    val id = pi.createSession(params)
    pi.openSession(id).use { s ->
        f.inputStream().use { inp -> s.openWrite("chatzo", 0, f.length()).use { out -> inp.copyTo(out); s.fsync(out) } }
        val it = Intent(ctx, InstallResultReceiver::class.java).setAction("rm.chatzo.app.INSTALL_RESULT").setPackage(ctx.packageName)
        val fl = android.app.PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) android.app.PendingIntent.FLAG_MUTABLE else 0)
        s.commit(android.app.PendingIntent.getBroadcast(ctx, id, it, fl).intentSender)
    }
}

/** receives the installer's answer; asks the person to confirm when the system needs it */
class InstallResultReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(c: android.content.Context, i: Intent) {
        if (i.getIntExtra(android.content.pm.PackageInstaller.EXTRA_STATUS, -1) == android.content.pm.PackageInstaller.STATUS_PENDING_USER_ACTION) {
            @Suppress("DEPRECATION")
            val a = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
            a?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { if (a != null) c.startActivity(a) } catch (e: Exception) {}
        }
    }
}

/** after the update is installed, open Chatzo again without the "Open" tap */
class ReplacedReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(c: android.content.Context, i: Intent) {
        if (i.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            try { c.startActivity(Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
        }
    }
}
