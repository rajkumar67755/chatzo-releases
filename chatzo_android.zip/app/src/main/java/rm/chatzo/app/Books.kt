package rm.chatzo.app

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** chat-list background: soft grey-blue studio colour, starts below the "Chatzo" title row */
@Composable
fun CatBg() {
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 60.dp
    Box(Modifier.fillMaxSize().padding(top = top)
        .background(Brush.verticalGradient(listOf(Color(0xFFA9B8C7), Color(0xFFBCC8D5), Color(0xFFCDD9E5)))))
}

private val BOOK_COLORS = listOf(
    listOf(Color(0xFF7C3AED), Color(0xFF312E81)), listOf(Color(0xFF0EA5E9), Color(0xFF0C4A6E)),
    listOf(Color(0xFFF97316), Color(0xFF7C2D12)), listOf(Color(0xFF10B981), Color(0xFF064E3B)),
    listOf(Color(0xFFEC4899), Color(0xFF831843))
)

/** Books tab. Style 0 = sliding cards (touch and drag left/right), style 1 = the earlier hover cards. Switch from the corner menu. */
@Composable
fun BooksScreen() {
    val ctx = LocalContext.current
    val sp = remember { ctx.getSharedPreferences("reader", android.content.Context.MODE_PRIVATE) }
    var style by remember { mutableIntStateOf(sp.getInt("booksStyle", 0)) }
    var reading by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    if (reading) { ReaderScreen("book1") { reading = false }; return }
    var open by remember { mutableIntStateOf(-1) }
    Column(
        Modifier.fillMaxSize().systemBarsPadding()
            .pointerInput(style) { detectTapGestures { open = -1 } }
    ) {
        Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Books", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Box {
                Text("⋮", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { menu = true }.padding(horizontal = 12.dp, vertical = 4.dp))
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text((if (style == 0) "✓  " else "     ") + "Sliding cards") },
                        onClick = { style = 0; sp.edit().putInt("booksStyle", 0).apply(); menu = false })
                    DropdownMenuItem(text = { Text((if (style == 1) "✓  " else "     ") + "Hover cards") },
                        onClick = { style = 1; sp.edit().putInt("booksStyle", 1).apply(); menu = false })
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        if (style == 0) SlidingBooks(onRead = { reading = true }) else HoverBooks(open, { open = it }, { reading = true })
    }
}

@Composable
private fun SlidingBooks(onRead: () -> Unit) {
    val names = listOf("Crime and Punishment", "Book 2", "Book 3", "Book 4", "Book 5")
    Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp).height(222.dp).clip(RoundedCornerShape(24.dp))
        .background(Brush.verticalGradient(listOf(Color(0xFFD9F3F8), Color(0xFFEFFAFC))))) {
        Box(Modifier.fillMaxWidth().height(74.dp).align(Alignment.BottomCenter).background(Color.Black))
        Text("Tap a book to read", color = Color(0x99335566), fontSize = 13.sp, modifier = Modifier.padding(start = 16.dp, top = 12.dp))
        LazyRow(
            Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 40.dp, bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            itemsIndexed(names) { i, n ->
                Column(
                    Modifier.width(116.dp).fillMaxHeight().clip(RoundedCornerShape(16.dp)).background(Color.White)
                        .clickable(enabled = i == 0) { onRead() }.padding(6.dp)
                ) {
                    Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(12.dp)).background(Brush.verticalGradient(BOOK_COLORS[i])),
                        contentAlignment = Alignment.Center) {
                        if (i == 0) Image(painterResource(R.drawable.book1), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        else Text("${i + 1}", color = Color(0x88FFFFFF), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(n, color = Color(0xFF6B7280), fontSize = 11.sp, maxLines = 1, modifier = Modifier.padding(top = 5.dp, start = 2.dp))
                    Text(if (i == 0) "Tap to read" else "Coming soon", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.padding(start = 2.dp))
                }
            }
        }
    }
}

@Composable
private fun HoverBooks(open: Int, setOpen: (Int) -> Unit, onRead: () -> Unit) {
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth().height(430.dp).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        BOOK_COLORS.forEachIndexed { i, c ->
            val w by animateFloatAsState(if (open == i) 5f else 1f, tween(350), label = "book$i")
            Box(
                Modifier.weight(w).fillMaxHeight().clip(RoundedCornerShape(16.dp))
                    .background(Brush.verticalGradient(c))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { if (i == 0 && open == 0) onRead() else setOpen(i) },
                contentAlignment = Alignment.Center
            ) {
                if (i == 0) {
                    Image(painterResource(R.drawable.book1), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    if (open == i) Text(
                        "Tap to read", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 14.dp)
                            .clip(RoundedCornerShape(12.dp)).background(Color(0x99000000)).padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                } else if (open == i) Text("Coming soon", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1, softWrap = false)
                else Text("${i + 1}", color = Color(0x88FFFFFF), fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
