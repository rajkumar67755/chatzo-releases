package rm.chatzo.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.Base64
import androidx.compose.runtime.mutableStateMapOf
import androidx.exifinterface.media.ExifInterface
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class Prof(val name: String = "", val phone: String = "", val bio: String = "", val photo: String = "")
data class Friend(
    val id: String, val name: String, val lastText: String, val lastAt: Long,
    val lastBy: String, val lastSt: String, val unread: Int
)
data class StatusItem(
    val uid: String, val img: String, val text: String, val color: Int, val at: Long,
    val name: String = "", val bio: String = "", val photo: String = ""
) {
    val live: Boolean get() = (img.isNotBlank() || text.isNotBlank()) && System.currentTimeMillis() - at < 86400000L
}
data class Msg(
    val id: String, val uid: String, val text: String, val img: String,
    val at: Long, val st: String, val deleted: Boolean,
    val rt: String = "", val ru: String = ""
)

data class Wall(val src: String, val dim: Int, val none: Boolean)
data class AdminUser(val id: String, val name: String, val phone: String, val email: String)
data class Report(val id: String, val by: String, val against: String, val reason: String)

object Repo {
    const val PUSH_URL = "https://chatzo-push.rrrajkumarmondal-a8c.workers.dev/"
    @Volatile var foreground = false
    @Volatile var lastPush = "(no message sent yet in this session)"
    @Volatile var tokenErr = ""

    suspend fun diag(ctx: Context): String {
        val sb = StringBuilder()
        sb.append("App version: 5.7\n")
        sb.append("Android: ").append(android.os.Build.VERSION.SDK_INT).append("\n")
        sb.append("Notifications allowed: ")
            .append(androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled()).append("\n")
        try {
            val t = com.google.firebase.messaging.FirebaseMessaging.getInstance().token.await()
            sb.append("Device token: OK\n")
            val m = me()
            if (m != null) {
                db.document("users/$m/private/fcm").set(mapOf("token" to t)).await()
                sb.append("Token saved: OK\n")
            }
        } catch (e: Exception) {
            sb.append("Token ERROR: ").append(e.message ?: e.toString()).append("\n")
        }
        sb.append("Last send to server: ").append(lastPush)
        return sb.toString()
    }

    fun saveToken(t: String) {
        val m = me() ?: return
        db.document("users/$m/private/fcm").set(mapOf("token" to t))
    }
    suspend fun clearToken() {
        val m = me() ?: return
        try { db.document("users/$m/private/fcm").delete().await() } catch (e: Exception) {}
    }
    suspend fun notifyPush(to: String, text: String) {
        withContext(Dispatchers.IO) {
            try {
                val tok = auth.currentUser?.getIdToken(false)?.await()?.token
                if (tok == null) { lastPush = "no login token"; return@withContext }
                val c = URL(PUSH_URL).openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.connectTimeout = 8000; c.readTimeout = 8000; c.doOutput = true
                c.setRequestProperty("Authorization", "Bearer $tok")
                c.setRequestProperty("Content-Type", "application/json")
                val body = JSONObject().put("to", to).put("text", text).toString()
                c.outputStream.use { it.write(body.toByteArray()) }
                val code = c.responseCode
                val resp = try {
                    (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
                } catch (e: Exception) { "" }
                lastPush = "HTTP $code $resp"
                c.disconnect()
            } catch (e: Exception) {
                lastPush = "ERROR: " + (e.message ?: e.toString())
            }
        }
    }
    val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()
    fun me(): String? = auth.currentUser?.uid

    fun chatId(a: String, b: String) = listOf(a, b).sorted().joinToString("_")

    fun normPhone(v: String): String {
        var d = v.filter { it.isDigit() }
        if (d.length == 10) d = "91$d"
        else if (d.length == 11 && d[0] == '0') d = "91" + d.substring(1)
        return d
    }

    private fun toProf(d: DocumentSnapshot) = Prof(
        d.getString("name") ?: "", d.getString("phone") ?: "",
        d.getString("bio") ?: "", d.getString("photo") ?: ""
    )

    // profile cache shared by all screens
    val profiles = mutableStateMapOf<String, Prof>()
    private val asked = HashSet<String>()
    fun profile(id: String): Prof? {
        val p = profiles[id]
        if (p != null) return p
        if (asked.add(id)) {
            db.document("users/$id").get().addOnSuccessListener { d ->
                profiles[id] = if (d.exists()) toProf(d) else Prof()
            }.addOnFailureListener { asked.remove(id) }
        }
        return null
    }

    /** null = no profile yet */
    suspend fun loadMyProfile(uid: String): Prof? {
        val d = db.document("users/$uid").get().await()
        if (!d.exists()) return null
        val p = toProf(d)
        profiles[uid] = p
        return p
    }

    suspend fun createProfile(user: FirebaseUser, name: String, phone: String): String? {
        return try {
            val ph = db.document("phones/$phone").get().await()
            if (ph.exists() && ph.getString("uid") != user.uid) return "This number is already used by another account."
            db.document("users/${user.uid}").set(mapOf("name" to name, "phone" to phone, "bio" to "", "photo" to "")).await()
            db.document("users/${user.uid}/private/info").set(mapOf("email" to (user.email ?: ""))).await()
            if (!ph.exists()) db.document("phones/$phone").set(mapOf("uid" to user.uid, "name" to name)).await()
            try { db.document("admin/owner").set(mapOf("uid" to user.uid)).await() } catch (e: Exception) {}
            profiles[user.uid] = Prof(name, phone, "", "")
            null
        } catch (e: Exception) { e.message ?: "Something went wrong" }
    }

    fun setPresence(on: Boolean) {
        val m = me() ?: return
        db.document("presence/$m").set(mapOf("on" to on, "at" to FieldValue.serverTimestamp()))
    }

    fun listenPresence(uid: String, cb: (Boolean, Long) -> Unit): ListenerRegistration =
        db.document("presence/$uid").addSnapshotListener { s, e ->
            if (e != null || s == null || !s.exists()) return@addSnapshotListener
            val t = s.getTimestamp("at", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L
            cb(s.getBoolean("on") == true, t)
        }

    fun listenFriends(cb: (List<Friend>) -> Unit): ListenerRegistration? {
        val m = me() ?: return null
        return db.collection("users/$m/friends").addSnapshotListener { s, e ->
            if (e != null || s == null) return@addSnapshotListener
            cb(s.documents.map { d ->
                Friend(
                    d.id, d.getString("name") ?: "",
                    d.getString("lastText") ?: "",
                    d.getTimestamp("lastAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L,
                    d.getString("lastBy") ?: "", d.getString("lastSt") ?: "",
                    (d.getLong("unread") ?: 0L).toInt()
                )
            })
        }
    }

    /** returns Pair(uid, Prof) or null */
    suspend fun searchPhone(ph: String): Pair<String, Prof>? {
        val p = db.document("phones/$ph").get().await()
        if (!p.exists()) return null
        val uid = p.getString("uid") ?: return null
        val d = db.document("users/$uid").get().await()
        val pr = if (d.exists()) toProf(d) else Prof(p.getString("name") ?: "User")
        profiles[uid] = pr
        return uid to pr
    }

    fun listenMessages(cid: String, cb: (List<Msg>) -> Unit): ListenerRegistration =
        db.collection("chats/$cid/messages").orderBy("at", Query.Direction.ASCENDING)
            .addSnapshotListener { s, e ->
                if (e != null || s == null) return@addSnapshotListener
                cb(s.documents.map { d ->
                    Msg(
                        d.id, d.getString("uid") ?: "", d.getString("text") ?: "",
                        d.getString("img") ?: "",
                        d.getTimestamp("at", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: System.currentTimeMillis(),
                        d.getString("st") ?: "sent", d.getBoolean("deleted") == true,
                        d.getString("rt") ?: "", d.getString("ru") ?: ""
                    )
                })
            }

    private suspend fun ensureFriend(other: String, otherName: String, myName: String, preview: String) {
        val m = me() ?: return
        db.document("users/$m/friends/$other").set(
            mapOf("name" to otherName.ifBlank { "Friend" }, "lastText" to preview,
                "lastAt" to FieldValue.serverTimestamp(), "lastBy" to m, "lastSt" to "sent"),
            SetOptions.merge()
        ).await()
        db.document("users/$other/friends/$m").set(
            mapOf("name" to myName.ifBlank { "Friend" }, "lastText" to preview,
                "lastAt" to FieldValue.serverTimestamp(), "lastBy" to m, "unread" to FieldValue.increment(1)),
            SetOptions.merge()
        ).await()
    }

    suspend fun syncLastSt(other: String, st: String) {
        val m = me() ?: return
        try { db.document("users/$m/friends/$other").set(mapOf("lastSt" to st), SetOptions.merge()).await() } catch (e: Exception) {}
    }

    suspend fun sendText(other: String, otherName: String, text: String, rt: String = "", ru: String = ""): String? = try {
        val m = me()!!
        val data = hashMapOf<String, Any>("uid" to m, "text" to text, "at" to FieldValue.serverTimestamp(), "st" to "sent")
        if (rt.isNotBlank()) { data["rt"] = rt.take(120); data["ru"] = ru }
        db.collection("chats/${chatId(m, other)}/messages").add(data).await()
        ensureFriend(other, otherName, profiles[m]?.name ?: "", text)
        notifyPush(other, text)
        null
    } catch (e: Exception) { e.message ?: "Not sent" }

    suspend fun sendImage(other: String, otherName: String, dataUrl: String, rt: String = "", ru: String = "", caption: String = ""): String? = try {
        val m = me()!!
        val data = hashMapOf<String, Any>("uid" to m, "img" to dataUrl, "at" to FieldValue.serverTimestamp(), "st" to "sent")
        if (caption.isNotBlank()) data["text"] = caption.take(500)
        if (rt.isNotBlank()) { data["rt"] = rt.take(120); data["ru"] = ru }
        db.collection("chats/${chatId(m, other)}/messages").add(data).await()
        ensureFriend(other, otherName, profiles[m]?.name ?: "", caption.ifBlank { "📷 Photo" })
        notifyPush(other, caption.ifBlank { "📷 Photo" })
        null
    } catch (e: Exception) { e.message ?: "Not sent" }

    suspend fun deleteMsg(other: String, id: String): String? = try {
        val m = me()!!
        db.document("chats/${chatId(m, other)}/messages/$id")
            .update(mapOf("deleted" to true, "text" to "", "img" to FieldValue.delete())).await()
        try {
            val last = db.collection("chats/${chatId(m, other)}/messages")
                .orderBy("at", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(1).get().await()
            if (last.documents.firstOrNull()?.id == id) {
                db.document("users/$m/friends/$other").set(mapOf("lastText" to "You deleted this message"), SetOptions.merge()).await()
                db.document("users/$other/friends/$m").set(mapOf("lastText" to "This message was deleted"), SetOptions.merge()).await()
            }
        } catch (e: Exception) {}
        null
    } catch (e: Exception) { e.message ?: "Couldn't delete" }

    /** mark other person's messages as read + clear my unread counter */
    suspend fun markRead(other: String, ids: List<String>) {
        val m = me() ?: return
        try {
            if (ids.isNotEmpty()) {
                val b = db.batch()
                ids.take(400).forEach { b.update(db.document("chats/${chatId(m, other)}/messages/$it"), "st", "read") }
                b.commit().await()
                db.document("users/$other/friends/$m").set(mapOf("lastSt" to "read"), SetOptions.merge()).await()
            }
            db.document("users/$m/friends/$other").set(mapOf("unread" to 0), SetOptions.merge()).await()
        } catch (e: Exception) {}
    }

    private val deliveredAt = HashMap<String, Long>()
    suspend fun markDelivered(other: String) {
        val m = me() ?: return
        val now = System.currentTimeMillis()
        if (now - (deliveredAt[other] ?: 0L) < 8000) return
        deliveredAt[other] = now
        try {
            val sn = db.collection("chats/${chatId(m, other)}/messages")
                .whereEqualTo("uid", other).whereEqualTo("st", "sent").limit(100).get().await()
            if (sn.isEmpty) return
            val b = db.batch()
            sn.documents.forEach { b.update(it.reference, "st", "delivered") }
            b.commit().await()
            db.document("users/$other/friends/$m").set(mapOf("lastSt" to "delivered"), SetOptions.merge()).await()
        } catch (e: Exception) {}
    }


    const val UPDATE_URL = "https://github.com/__OWNER__/chatzo-releases/releases/latest/download/version.json"

    /** returns (versionName, apkUrl, note) when a newer version is published, else null */
    suspend fun checkUpdate(ctx: Context): Triple<String, String, String>? = withContext(Dispatchers.IO) {
        try {
            val c = URL(UPDATE_URL).openConnection() as HttpURLConnection
            c.connectTimeout = 5000; c.readTimeout = 5000; c.setRequestProperty("Cache-Control", "no-cache")
            if (c.responseCode != 200) return@withContext null
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            c.disconnect()
            val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
            val cur = androidx.core.content.pm.PackageInfoCompat.getLongVersionCode(pi)
            if (j.optLong("code", 0L) > cur) Triple(j.optString("name", ""), j.optString("url", ""), j.optString("note", "")) else null
        } catch (e: Throwable) { null }
    }

    /** downloads the new APK into the cache folder; returns the file or null on failure */
    suspend fun downloadApk(ctx: Context, url: String, onProgress: (Int) -> Unit): java.io.File? = withContext(Dispatchers.IO) {
        try {
            val dir = java.io.File(ctx.cacheDir, "update"); dir.mkdirs()
            val f = java.io.File(dir, "Chatzo.apk"); if (f.exists()) f.delete()
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 20000
            if (c.responseCode != 200) return@withContext null
            val total = c.contentLengthLong
            var done = 0L; var last = -1
            c.inputStream.use { inp ->
                f.outputStream().use { out ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = inp.read(buf); if (n < 0) break
                        out.write(buf, 0, n); done += n
                        if (total > 0) { val pc = (done * 100 / total).toInt(); if (pc != last) { last = pc; onProgress(pc) } }
                    }
                }
            }
            c.disconnect()
            if (f.length() < 100000) null else f
        } catch (e: Throwable) { null }
    }

    // ---------- status (24 hours) ----------
    /** listens to the status of each id; calls back with the live ones (younger than 24 h). returns a stop function */
    fun listenStatuses(ids: Collection<String>, cb: (Map<String, StatusItem>) -> Unit): () -> Unit {
        val map = HashMap<String, StatusItem>()
        val regs = ids.distinct().map { id ->
            db.document("status/$id").addSnapshotListener { d, e ->
                if (e != null || d == null) return@addSnapshotListener
                val at = d.getLong("at") ?: 0L
                if (d.exists()) {
                    map[id] = StatusItem(
                        id, d.getString("img") ?: "", d.getString("text") ?: "", (d.getLong("color") ?: 0L).toInt(), at,
                        d.getString("sname") ?: "", d.getString("sbio") ?: "", d.getString("sphoto") ?: ""
                    )
                } else map.remove(id)
                cb(HashMap(map))
            }
        }
        return { regs.forEach { it.remove() } }
    }
    suspend fun postStatus(img: String, text: String, color: Int): String? = try {
        val m = me()
        if (m == null) "Not signed in" else {
            db.document("status/$m").set(
                mapOf("uid" to m, "img" to img, "text" to text, "color" to color, "at" to System.currentTimeMillis()),
                SetOptions.merge()
            ).await()
            null
        }
    } catch (e: Exception) { e.message ?: "Couldn't post" }
    suspend fun deleteStatus(): String? = try {
        val m = me()
        if (m != null) db.document("status/$m").set(mapOf("uid" to m, "img" to "", "text" to "", "at" to 0L), SetOptions.merge()).await()
        null
    } catch (e: Exception) { e.message ?: "Couldn't delete" }
    suspend fun saveStatusProfile(name: String, bio: String, photo: String?): String? = try {
        val m = me()
        if (m == null) "Not signed in" else {
            val data = hashMapOf<String, Any>("uid" to m, "sname" to name.trim().take(40), "sbio" to bio.trim().take(150))
            if (photo != null) data["sphoto"] = photo
            db.document("status/$m").set(data, SetOptions.merge()).await()
            null
        }
    } catch (e: Exception) { e.message ?: "Couldn't save" }

    // ---------- blocks, wallpapers, profile, admin ----------
    private fun listenIds(path: String, cb: (Set<String>) -> Unit): ListenerRegistration =
        db.collection(path).addSnapshotListener { s, e ->
            if (e != null || s == null) return@addSnapshotListener
            cb(s.documents.map { it.id }.toSet())
        }
    fun listenMyBlocks(cb: (Set<String>) -> Unit) = listenIds("users/${me()}/blocks", cb)
    fun listenGlobalBlocked(cb: (Set<String>) -> Unit) = listenIds("blocked", cb)

    fun listenWall(key: String, cb: (Wall?) -> Unit): ListenerRegistration =
        db.document("users/${me()}/private/$key").addSnapshotListener { s, e ->
            if (e != null || s == null) return@addSnapshotListener
            if (!s.exists()) cb(null)
            else cb(Wall(s.getString("src") ?: "", (s.getLong("dim") ?: 0L).toInt(), s.getBoolean("none") == true))
        }

    suspend fun setBlock(other: String, on: Boolean): String? = try {
        val r = db.document("users/${me()}/blocks/$other")
        if (on) r.set(mapOf("at" to FieldValue.serverTimestamp())).await() else r.delete().await()
        null
    } catch (e: Exception) { e.message ?: "Error" }

    suspend fun report(other: String, reason: String): String? = try {
        val m = me()!!
        db.collection("reports").add(
            mapOf("by" to m, "against" to other, "reason" to reason, "chatId" to chatId(m, other), "at" to FieldValue.serverTimestamp())
        ).await()
        null
    } catch (e: Exception) { e.message ?: "Error" }

    suspend fun saveWall(key: String, src: String, dim: Int): String? = try {
        db.document("users/${me()}/private/$key").set(mapOf("src" to src, "dim" to dim)).await(); null
    } catch (e: Exception) { e.message ?: "Error" }

    suspend fun removeWall(key: String, hasAll: Boolean): String? = try {
        val r = db.document("users/${me()}/private/$key")
        if (hasAll) r.set(mapOf("none" to true)).await() else r.delete().await()
        null
    } catch (e: Exception) { e.message ?: "Error" }

    suspend fun readAll(ids: List<String>) {
        val m = me() ?: return
        try {
            val b = db.batch()
            ids.forEach { b.update(db.document("users/$m/friends/$it"), "unread", 0) }
            b.commit().await()
        } catch (e: Exception) {}
    }

    suspend fun saveProfile(name: String, bio: String, photo: String?, phone: String?): String? {
        val m = me() ?: return "Not signed in"
        return try {
            val data = HashMap<String, Any>()
            data["name"] = name; data["bio"] = bio
            if (photo != null) data["photo"] = photo
            if (!phone.isNullOrBlank()) {
                val ex = db.document("phones/$phone").get().await()
                if (ex.exists() && ex.getString("uid") != m) return "This number is already used by another account."
                if (!ex.exists()) db.document("phones/$phone").set(mapOf("uid" to m, "name" to name)).await()
                data["phone"] = phone
            }
            db.document("users/$m").set(data, SetOptions.merge()).await()
            val old = profiles[m] ?: Prof()
            profiles[m] = Prof(name, (data["phone"] as? String) ?: old.phone, bio, photo ?: old.photo)
            null
        } catch (e: Exception) { e.message ?: "Couldn't save" }
    }

    suspend fun isAdmin(): Boolean = try {
        db.document("admin/owner").get().await().getString("uid") == me()
    } catch (e: Exception) { false }

    suspend fun isBlockedByAdmin(): Boolean = try {
        db.document("blocked/${me()}").get().await().exists()
    } catch (e: Exception) { false }

    suspend fun adminUsers(): List<AdminUser> {
        val out = ArrayList<AdminUser>()
        val sn = db.collection("users").get().await()
        for (d in sn.documents) {
            val email = try { db.document("users/${d.id}/private/info").get().await().getString("email") ?: "" } catch (e: Exception) { "" }
            out.add(AdminUser(d.id, d.getString("name") ?: "", d.getString("phone") ?: "", email))
        }
        return out
    }

    suspend fun adminReports(): List<Report> {
        val sn = db.collection("reports").get().await()
        return sn.documents.map { Report(it.id, it.getString("by") ?: "", it.getString("against") ?: "", it.getString("reason") ?: "") }
    }

    suspend fun setGlobalBlock(id: String, on: Boolean): String? = try {
        val r = db.document("blocked/$id")
        if (on) r.set(mapOf("at" to FieldValue.serverTimestamp())).await() else r.delete().await()
        null
    } catch (e: Exception) { e.message ?: "Error" }

    fun loadBitmap(ctx: Context, uri: Uri, maxSide: Int): Bitmap? = try {
        val bo = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bo) }
        var sample = 1
        while (bo.outWidth / sample > maxSide * 2 || bo.outHeight / sample > maxSide * 2) sample *= 2
        val o = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } ?: return null
        val rot = try {
            ctx.contentResolver.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) { 0f }
        val k = maxSide.toFloat() / maxOf(bmp.width, bmp.height)
        val mx = Matrix()
        if (k < 1f) mx.postScale(k, k)
        if (rot != 0f) mx.postRotate(rot)
        if (!mx.isIdentity) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, mx, true)
        bmp
    } catch (e: Throwable) { null }

    fun toDataUrl(b: Bitmap, q: Int): String {
        val bs = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, q, bs)
        return "data:image/jpeg;base64," + Base64.encodeToString(bs.toByteArray(), Base64.NO_WRAP)
    }

    // ---- images (stored as base64 data URLs inside Firestore) ----
    fun decodeDataUrl(src: String): android.graphics.Bitmap? = try {
        val b64 = if (src.contains("base64,")) src.substringAfter("base64,") else src
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    } catch (e: Throwable) { null }

    fun readPhoto(ctx: Context, uri: Uri, maxSide: Int, limit: Int): String? = try {
        val bo = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bo) }
        var sample = 1
        while (bo.outWidth / sample > maxSide * 2 || bo.outHeight / sample > maxSide * 2) sample *= 2
        val o = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } ?: return null
        val rot = try {
            ctx.contentResolver.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) { 0f }
        val k = maxSide.toFloat() / maxOf(bmp.width, bmp.height)
        val mx = Matrix()
        if (k < 1f) mx.postScale(k, k)
        if (rot != 0f) mx.postRotate(rot)
        if (!mx.isIdentity) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, mx, true)
        var q = 82
        var out: String
        do {
            val bs = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, q, bs)
            out = "data:image/jpeg;base64," + Base64.encodeToString(bs.toByteArray(), Base64.NO_WRAP)
            q -= 10
        } while (out.length > limit && q > 20)
        if (out.length > limit) null else out
    } catch (e: Throwable) { null }
}
