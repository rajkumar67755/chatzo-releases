package rm.chatzo.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp

// Original glossy "3D" emoji drawn in code (our own artwork). Only the ones in GLOSS_KIND are drawn; all others use the phone's emoji.
val GLOSS_KIND: Map<String, String> = mapOf(
    "😀" to "grin", "😃" to "grin", "😄" to "grin", "😁" to "grin",
    "😆" to "laugh", "😂" to "joy", "🤣" to "joy",
    "🙂" to "smile", "😊" to "blush", "☺" to "blush", "😉" to "wink",
    "😍" to "loveeyes", "🥰" to "loveeyes", "😘" to "kiss",
    "😎" to "cool", "😢" to "sad", "😭" to "cry", "😡" to "angry", "😠" to "angry",
    "😮" to "wow", "😲" to "wow", "😴" to "sleep", "😐" to "meh",
    "❤" to "heart:E11D2E", "🧡" to "heart:F97316", "💛" to "heart:FACC15", "💚" to "heart:22C55E",
    "💙" to "heart:3B82F6", "💜" to "heart:8B5CF6", "🖤" to "heart:27272A", "🤍" to "heart:F4F4F5", "💖" to "heart:EC4899"
)

fun glossKind(e: String): String? = GLOSS_KIND[e.replace("️", "")]

private val INK = Color(0xFF4A2C0A)

private fun heart(cx: Float, cy: Float, a: Float): Path = Path().apply {
    moveTo(cx, cy + a * 0.95f)
    cubicTo(cx - a * 1.7f, cy - a * 0.1f, cx - a * 0.8f, cy - a * 1.3f, cx, cy - a * 0.4f)
    cubicTo(cx + a * 0.8f, cy - a * 1.3f, cx + a * 1.7f, cy - a * 0.1f, cx, cy + a * 0.95f)
    close()
}

private fun DrawScope.gloss(s: Float, x: Float, y: Float, w: Float, h: Float, a: Float = 0.55f) {
    drawOval(
        Brush.verticalGradient(listOf(Color.White.copy(alpha = a), Color.Transparent), startY = y * s, endY = (y + h) * s),
        Offset(x * s, y * s), Size(w * s, h * s)
    )
}

private fun DrawScope.stroke(s: Float, p: Path, w: Float = 0.04f, c: Color = INK) =
    drawPath(p, c, style = Stroke(width = w * s, cap = StrokeCap.Round))

private fun DrawScope.dotEye(s: Float, x: Float, y: Float, r: Float = 0.055f) {
    drawOval(INK, Offset((x - r) * s, (y - r * 1.25f) * s), Size(2 * r * s, 2.5f * r * s))
    drawCircle(Color.White, r * 0.35f * s, Offset((x - r * 0.25f) * s, (y - r * 0.6f) * s))
}

private fun DrawScope.arcEye(s: Float, x: Float, y: Float, up: Boolean = true) {
    val d = if (up) -0.08f else 0.08f
    stroke(s, Path().apply { moveTo((x - 0.075f) * s, (y + 0.02f) * s); quadraticBezierTo(x * s, (y + d) * s, (x + 0.075f) * s, (y + 0.02f) * s) })
}

private fun DrawScope.smile(s: Float, w: Float = 0.04f) =
    stroke(s, Path().apply { moveTo(0.3f * s, 0.62f * s); quadraticBezierTo(0.5f * s, 0.82f * s, 0.7f * s, 0.62f * s) }, w)

private fun DrawScope.openMouth(s: Float) {
    val m = Path().apply { moveTo(0.26f * s, 0.57f * s); cubicTo(0.3f * s, 0.88f * s, 0.7f * s, 0.88f * s, 0.74f * s, 0.57f * s); close() }
    drawPath(m, Color(0xFF5B2A0A))
    drawOval(Color(0xFFF0707A), Offset(0.38f * s, 0.74f * s), Size(0.24f * s, 0.1f * s))
    drawRect(Color.White, Offset(0.32f * s, 0.57f * s), Size(0.36f * s, 0.05f * s))
}

private fun DrawScope.tear(s: Float, x: Float, y: Float, len: Float = 0.1f) {
    drawOval(Color(0xFF38BDF8), Offset((x - 0.03f) * s, y * s), Size(0.06f * s, len * s))
}

private fun DrawScope.blush(s: Float) {
    val c = Color(0x66F25C54)
    drawOval(c, Offset(0.15f * s, 0.55f * s), Size(0.15f * s, 0.09f * s))
    drawOval(c, Offset(0.70f * s, 0.55f * s), Size(0.15f * s, 0.09f * s))
}

@Composable
fun GlossEmoji(e: String, size: Dp) {
    val kind = glossKind(e) ?: return
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension
        if (kind.startsWith("heart:")) {
            val base = Color(kind.removePrefix("heart:").toLong(16) or 0xFF000000)
            val dark = Color(base.red * 0.65f, base.green * 0.65f, base.blue * 0.65f, 1f)
            val h = heart(0.5f * s, 0.5f * s, 0.34f * s)
            drawPath(h, Brush.radialGradient(listOf(base, dark), Offset(0.38f * s, 0.32f * s), 0.7f * s))
            drawPath(h, dark, style = Stroke(width = 0.012f * s))
            drawOval(Color.White.copy(alpha = 0.55f), Offset(0.22f * s, 0.25f * s), Size(0.2f * s, 0.12f * s))
            return@Canvas
        }
        val angry = kind == "angry"
        val c1 = if (angry) Color(0xFFFF8A65) else Color(0xFFFFE57A)
        val c2 = if (angry) Color(0xFFE53935) else Color(0xFFFFB300)
        val c3 = if (angry) Color(0xFFB71C1C) else Color(0xFFE08A00)
        drawCircle(Color(0x33000000), 0.5f * s, Offset(0.5f * s, 0.54f * s))
        drawCircle(Brush.radialGradient(listOf(c1, c2, c3), Offset(0.38f * s, 0.3f * s), 0.78f * s), 0.48f * s, Offset(0.5f * s, 0.5f * s))
        drawCircle(c3.copy(alpha = 0.5f), 0.48f * s, Offset(0.5f * s, 0.5f * s), style = Stroke(width = 0.015f * s))
        gloss(s, 0.2f, 0.06f, 0.6f, 0.3f)
        when (kind) {
            "grin" -> { dotEye(s, 0.34f, 0.4f); dotEye(s, 0.66f, 0.4f); openMouth(s) }
            "laugh" -> { arcEye(s, 0.33f, 0.4f); arcEye(s, 0.67f, 0.4f); openMouth(s) }
            "joy" -> { arcEye(s, 0.33f, 0.4f); arcEye(s, 0.67f, 0.4f); openMouth(s); tear(s, 0.2f, 0.45f); tear(s, 0.8f, 0.45f) }
            "smile" -> { dotEye(s, 0.34f, 0.4f); dotEye(s, 0.66f, 0.4f); smile(s) }
            "blush" -> { arcEye(s, 0.33f, 0.4f); arcEye(s, 0.67f, 0.4f); smile(s); blush(s) }
            "wink" -> { dotEye(s, 0.34f, 0.4f); arcEye(s, 0.67f, 0.4f); smile(s) }
            "loveeyes" -> {
                val r = Brush.radialGradient(listOf(Color(0xFFFF5252), Color(0xFFC62828)), Offset(0.4f * s, 0.35f * s), 0.3f * s)
                drawPath(heart(0.32f * s, 0.4f * s, 0.11f * s), r)
                drawPath(heart(0.68f * s, 0.4f * s, 0.11f * s), r)
                openMouth(s)
            }
            "kiss" -> {
                dotEye(s, 0.34f, 0.4f); arcEye(s, 0.67f, 0.4f)
                drawOval(Color(0xFF5B2A0A), Offset(0.45f * s, 0.62f * s), Size(0.1f * s, 0.12f * s))
                drawPath(heart(0.78f * s, 0.7f * s, 0.09f * s), Color(0xFFE53935))
            }
            "cool" -> {
                val g = Brush.verticalGradient(listOf(Color(0xFF424242), Color(0xFF000000)), startY = 0.33f * s, endY = 0.5f * s)
                drawRoundRect(g, Offset(0.15f * s, 0.33f * s), Size(0.32f * s, 0.17f * s), androidx.compose.ui.geometry.CornerRadius(0.06f * s))
                drawRoundRect(g, Offset(0.53f * s, 0.33f * s), Size(0.32f * s, 0.17f * s), androidx.compose.ui.geometry.CornerRadius(0.06f * s))
                drawRect(Color.Black, Offset(0.45f * s, 0.35f * s), Size(0.1f * s, 0.025f * s))
                drawOval(Color.White.copy(alpha = 0.35f), Offset(0.19f * s, 0.35f * s), Size(0.12f * s, 0.04f * s))
                drawOval(Color.White.copy(alpha = 0.35f), Offset(0.57f * s, 0.35f * s), Size(0.12f * s, 0.04f * s))
                smile(s)
            }
            "sad" -> {
                dotEye(s, 0.34f, 0.42f); dotEye(s, 0.66f, 0.42f); tear(s, 0.3f, 0.5f)
                stroke(s, Path().apply { moveTo(0.34f * s, 0.74f * s); quadraticBezierTo(0.5f * s, 0.6f * s, 0.66f * s, 0.74f * s) })
            }
            "cry" -> {
                arcEye(s, 0.33f, 0.4f, false); arcEye(s, 0.67f, 0.4f, false)
                tear(s, 0.28f, 0.45f, 0.3f); tear(s, 0.72f, 0.45f, 0.3f)
                drawOval(Color(0xFF5B2A0A), Offset(0.4f * s, 0.62f * s), Size(0.2f * s, 0.16f * s))
            }
            "angry" -> {
                dotEye(s, 0.34f, 0.46f); dotEye(s, 0.66f, 0.46f)
                stroke(s, Path().apply { moveTo(0.22f * s, 0.3f * s); lineTo(0.42f * s, 0.38f * s) }, 0.05f)
                stroke(s, Path().apply { moveTo(0.78f * s, 0.3f * s); lineTo(0.58f * s, 0.38f * s) }, 0.05f)
                stroke(s, Path().apply { moveTo(0.34f * s, 0.74f * s); quadraticBezierTo(0.5f * s, 0.6f * s, 0.66f * s, 0.74f * s) })
            }
            "wow" -> { dotEye(s, 0.34f, 0.4f); dotEye(s, 0.66f, 0.4f); drawOval(Color(0xFF5B2A0A), Offset(0.43f * s, 0.6f * s), Size(0.14f * s, 0.2f * s)) }
            "sleep" -> {
                arcEye(s, 0.33f, 0.42f, false); arcEye(s, 0.67f, 0.42f, false)
                drawOval(Color(0xFF5B2A0A), Offset(0.44f * s, 0.65f * s), Size(0.12f * s, 0.09f * s))
            }
            else -> { dotEye(s, 0.34f, 0.4f); dotEye(s, 0.66f, 0.4f); stroke(s, Path().apply { moveTo(0.35f * s, 0.7f * s); lineTo(0.65f * s, 0.7f * s) }) }
        }
    }
}
