package rm.chatzo.app

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Book text is hosted online (public repo) as zip files so it can be updated without an app update. */
object BookNet {
    const val BASE = "https://raw.githubusercontent.com/rajkumar67755/chatzo-releases/main/"
    private var en: Map<String, ByteArray> = emptyMap()
    private var bn: Map<String, ByteArray> = emptyMap()

    fun reset() { en = emptyMap(); bn = emptyMap() }

    private fun zip(path: String): Map<String, ByteArray>? = try {
        val c = URL(BASE + path).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 20000; c.setRequestProperty("Cache-Control", "no-cache")
        if (c.responseCode != 200) null else {
            val m = HashMap<String, ByteArray>()
            java.util.zip.ZipInputStream(c.inputStream.buffered()).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    if (!e.isDirectory) m[e.name.substringAfterLast('/')] = z.readBytes()
                }
            }
            c.disconnect(); m
        }
    } catch (e: Throwable) { null }

    class Chapter(val title: String, val page: Int)
    class Index(val title: String, val author: String, val pages: Int, val per: Int, val bn: Int, val chapters: List<Chapter>)

    suspend fun index(book: String): Index? = withContext(Dispatchers.IO) {
        val f = zip("${book}_files.zip") ?: return@withContext null
        en = f
        bn = zip("${book}_bn.zip") ?: emptyMap()
        try {
            val j = JSONObject(String(f["${book}_index.json"] ?: return@withContext null, Charsets.UTF_8))
            val ca = j.getJSONArray("chapters")
            val nb = bn["${book}_bn_index.json"]?.let { JSONObject(String(it, Charsets.UTF_8)).optInt("bn", 0) } ?: 0
            Index(j.optString("title"), j.optString("author"), j.getInt("pages"), j.optInt("per", 20), nb,
                (0 until ca.length()).map { Chapter(ca.getJSONObject(it).getString("t"), ca.getJSONObject(it).getInt("p")) })
        } catch (e: Throwable) { null }
    }

    private fun chunk(book: String, lang: String, n: Int): List<String>? {
        val src = if (lang == "bn") bn else en
        val b = src["${book}_${lang}_${"%03d".format(n)}.json"] ?: return null
        return try {
            val a = JSONArray(String(b, Charsets.UTF_8)); (0 until a.length()).map { a.getString(it) }
        } catch (e: Throwable) { null }
    }

    /** returns (text, isBengali) or null when offline */
    suspend fun page(book: String, ix: Index, p: Int): Pair<String, Boolean>? = withContext(Dispatchers.IO) {
        val n = p / ix.per + 1; val k = p % ix.per
        if (p < ix.bn) {
            val b = chunk(book, "bn", n)
            if (b != null && k < b.size) return@withContext Pair(b[k], true)
        }
        val e = chunk(book, "en", n) ?: return@withContext null
        if (k < e.size) Pair(e[k], false) else null
    }
}

@Composable
fun ReaderScreen(book: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val sp = remember { ctx.getSharedPreferences("reader", Context.MODE_PRIVATE) }
    var ix by remember { mutableStateOf<BookNet.Index?>(null) }
    var failed by remember { mutableStateOf(false) }
    var tryAgain by remember { mutableIntStateOf(0) }
    var page by remember { mutableIntStateOf(sp.getInt("$book.page", 0)) }
    var fs by remember { mutableIntStateOf(sp.getInt("$book.fs", 19)) }
    var content by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    var loading by remember { mutableStateOf(true) }
    var showList by remember { mutableStateOf(false) }

    LaunchedEffect(tryAgain) {
        failed = false; BookNet.reset()
        val r = BookNet.index(book)
        if (r == null) failed = true else { ix = r; if (page >= r.pages) page = 0 }
    }
    LaunchedEffect(ix, page, tryAgain) {
        val x = ix ?: return@LaunchedEffect
        loading = true
        val r = BookNet.page(book, x, page)
        if (r == null) failed = true else { content = r; failed = false; sp.edit().putInt("$book.page", page).apply() }
        loading = false
    }
    BackHandler { if (showList) showList = false else onClose() }

    Column(Modifier.fillMaxSize().background(Color(0xFF0B0B10)).systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("‹", color = Color.White, fontSize = 32.sp, modifier = Modifier.clickable { onClose() }.padding(horizontal = 12.dp))
            Text(ix?.title ?: "Book", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
            Text("A−", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { fs = (fs - 1).coerceAtLeast(14); sp.edit().putInt("$book.fs", fs).apply() }.padding(10.dp))
            Text("A+", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { fs = (fs + 1).coerceAtMost(30); sp.edit().putInt("$book.fs", fs).apply() }.padding(10.dp))
            Text("☰", color = Color.White, fontSize = 22.sp, modifier = Modifier.clickable { showList = true }.padding(10.dp))
        }
        val x = ix
        if (failed && content == null || (failed && x == null)) {
            Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("Connect to the internet to read this book.", color = Color.White, fontSize = 16.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
                Text("Try again", color = Color.White, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xFF7C3AED)).clickable { tryAgain++ }.padding(horizontal = 22.dp, vertical = 10.dp))
            }
        } else if (x == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("Loading…", color = Color(0xFFAAAAAA)) }
        } else {
            val ch = x.chapters.lastOrNull { it.page <= page }
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    (ch?.title ?: "") + (if (x.bn > 0) "  •  Bengali: pages 1–${x.bn}" else ""),
                    color = Color(0xFF9CA3AF), fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f)
                )
                if (page < x.pages - 1) Text("Next ›", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFF7C3AED)).clickable { page++ }.padding(horizontal = 14.dp, vertical = 5.dp))
            }
            val c = content
            Box(
                Modifier.weight(1f).fillMaxWidth().pointerInput(page, x) {
                    var sum = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { sum = 0f },
                        onDragEnd = {
                            if (sum < -90f && page < x.pages - 1) page++
                            else if (sum > 90f && page > 0) page--
                        }
                    ) { _, d -> sum += d }
                }
            ) {
                val sc = rememberScrollState()
                LaunchedEffect(page) { sc.scrollTo(0) }
                if (c != null) Text(
                    c.first, color = Color(0xFFE8E8EE), fontSize = fs.sp, lineHeight = (fs * 1.6f).sp,
                    modifier = Modifier.fillMaxSize().verticalScroll(sc).padding(horizontal = 18.dp, vertical = 8.dp)
                )
                if (loading && c == null) Text("Loading…", color = Color(0xFFAAAAAA), modifier = Modifier.align(Alignment.Center))
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("‹ Prev", color = if (page > 0) Color.White else Color(0xFF555555), fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xFF1F1F2B)).clickable(enabled = page > 0) { page-- }.padding(horizontal = 18.dp, vertical = 9.dp))
                Text("Page ${page + 1} / ${x.pages}", color = Color(0xFFCCCCCC), fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                Text("Next ›", color = if (page < x.pages - 1) Color.White else Color(0xFF555555), fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xFF7C3AED)).clickable(enabled = page < x.pages - 1) { page++ }.padding(horizontal = 18.dp, vertical = 9.dp))
            }
        }
    }

    val x = ix
    if (showList && x != null) {
        Box(Modifier.fillMaxSize().background(Color(0xCC000000)).clickable { showList = false }.systemBarsPadding().padding(24.dp)) {
            Column(Modifier.align(Alignment.Center).clip(RoundedCornerShape(18.dp)).background(Color(0xFF1B1B26)).padding(vertical = 10.dp)) {
                Text("Chapters", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp))
                LazyColumn(Modifier.heightIn(max = 480.dp)) {
                    itemsIndexed(x.chapters) { _, c ->
                        Text(
                            c.title + "  ·  p.${c.page + 1}", color = Color.White, fontSize = 15.sp,
                            modifier = Modifier.fillMaxWidth().clickable { page = c.page; showList = false }.padding(horizontal = 18.dp, vertical = 11.dp)
                        )
                    }
                }
            }
        }
    }
}
